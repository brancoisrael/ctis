/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.guia.emissao;

import br.gov.tredf.tresaudeAdm.bean.Guia;
import br.gov.tredf.tresaudeAdm.bean.GuiaProcedimento;
import br.gov.tredf.tresaudeAdm.bean.OrigemGuia;
import br.gov.tredf.tresaudeAdm.bean.Situacao;
import br.gov.tredf.tresaudeAdm.bean.TipoGuia;
import br.gov.tredf.tresaudeAdm.bean.Usuario;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import br.gov.tredf.tresaudeAdm.bean.auto._Usuario;
import br.gov.tredf.tresaudeAdm.relatorioPDF.RelatorioPDF;
import br.gov.tredf.tresaudeAdm.utils.StringMethods;
import br.gov.tredf.tresaudeAdm.utils.Util;
import com.lowagie.text.BadElementException;
import com.lowagie.text.Cell;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.PdfWriter;
import java.io.ByteArrayOutputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.naming.factory.EjbFactory;

/**
 * @author igor
 */
public class GuiaEmissaoImpressao extends RelatorioPDF {

    Paragraph paragrafoTemp = null;
    Table tabelaTemp = null;
    Cell celulaTemp = null;
    Chunk chunkTemp = null;
    
    int SEM_BORDA = 0;
    float CELL_PADDING = 1f;

    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    DecimalFormat decimalFormat = new DecimalFormat("###,##0.00");

    Double valorConsultasUrgentes = 0.0;
    
    String codUsuarioLogado = null;
    public synchronized boolean imprime(HttpServletRequest request, HttpServletResponse response, ByteArrayOutputStream pBaos) throws DocumentException, BadElementException, Exception {

        //===== C�digo Igor =====
        String anoExercicio = request.getParameter("anoExercicio");
        String strNumGuia = request.getParameter("numGuia");
        String strCodTipGuia = request.getParameter("codTipGuia");
        Integer numGuia = null;
        Integer codTipGuia = null;

        if (strNumGuia == null || strNumGuia.equals("")) {
            throw new ServletException("Par�metro numGuia est� com valor nulo ou em branco");
        } else {
            try {
                numGuia = new Integer(strNumGuia);
            } catch (Exception e) {
                throw new ServletException("N�o foi poss�vel converter o par�metro numGuia para inteiro", e);
            }
        }

        if (anoExercicio == null || anoExercicio.equals("")) {
            throw new ServletException("Par�metro anoExerc�cio est� com valor nulo ou em branco");
        }

        if (strCodTipGuia == null || strCodTipGuia.equals("")) {
            throw new ServletException("Par�metro codTipGuia est� com valor nulo ou em branco");
        } else {
            try {
                codTipGuia = new Integer(strCodTipGuia);
            } catch (Exception e) {
                throw new ServletException("N�o foi poss�vel converter o par�metro codTipGuia para inteiro", e);
            }
        }

        DataContext context = ServletUtil.getSessionContext(request.getSession());
        
        codUsuarioLogado = request.getRemoteUser();        
        UsuarioAutorizado usuarioAutorizado = getUsuarioAutorizado(context);
        Integer codCredenciado = usuarioAutorizado.getToCredenciadoAutorizado().getCodCredenciado();
        

        Object[] tipoGuiaValues = TipoGuia.getTiposDeGuia();
         
        Expression exp = null;
        exp = ExpressionFactory.matchDbExp(Guia.NUM_GUIA_PK_COLUMN, numGuia);
        exp = exp.andExp(ExpressionFactory.matchExp(Guia.ANO_EXERCICIO_PROPERTY, anoExercicio));             
        exp = exp.andExp(ExpressionFactory.matchDbExp(Guia.TO_CREDENCIADO_PROPERTY, codCredenciado));        
        exp = exp.andExp(ExpressionFactory.inExp(Guia.TO_TIPO_GUIA_PROPERTY, tipoGuiaValues));

        SelectQuery select = new SelectQuery(Guia.class, exp);
        List<Guia> lista = context.performQuery(select);        
        Guia guia = lista.get(0);
        guia.setToUsuarioAutorizadoSolicita(usuarioAutorizado);           
                
        Map<String, Object> mapPk = new HashMap<String, Object>();
        mapPk.put(Usuario.USERNAME_PK_COLUMN, guia.getToUsuarioAutorizacaoTRE().getUserName());
        Usuario usuario = (Usuario)DataObjectUtils.objectForPK(context,Usuario.class,mapPk);
        
        guia.setToUsuarioAutorizacaoTRE(usuario);
        
        Expression expGProcedimento = null;
        expGProcedimento = ExpressionFactory.matchDbExp(GuiaProcedimento.NUM_GUIA_PK_COLUMN, numGuia);        
        expGProcedimento = expGProcedimento.andExp(ExpressionFactory.matchDbExp(GuiaProcedimento.COD_TIP_GUIA_PK_COLUMN,codTipGuia));
        SelectQuery queryGuiaProcedimento = new SelectQuery(GuiaProcedimento.class, expGProcedimento);
        List<GuiaProcedimento> listGuiaProcedimento = context.performQuery(queryGuiaProcedimento); 
        
        for (GuiaProcedimento guiaProcedimento : listGuiaProcedimento) {
            guia.addToGuiaProcedimentoArray(guiaProcedimento);            
        }
        
//        addGuiaProcedimentoArray(numGuia, context, guia);
        
        if (guia == null) {
            throw new ServletException("Guia inexistente");
        }

        //==== C�digo Camila ====
        if(guia.getToSituacao().getCodSituacao()==Situacao.SITUACAO_AUTORIZADA){
            atualizarDadosGuia(guia, context, request);
        }
        valorConsultasUrgentes = 0.0;
        
        Document documento = new Document(PageSize.A4, 40, 40, 6, 6);//int marginLeft,   int marginRight,   int marginTop,   int marginBottom
        PdfWriter pdf = PdfWriter.getInstance(documento, pBaos);
        documento.setHeader(RelatorioPDF.getHeader());
        if(guia.getToUsuarioAutorizadoSolicita()!=null){
            //Se � uma guia solicitada
            documento.setFooter(getFooter(guia));
        }else{
            documento.setFooter(getRodapeEmissao());
        }
        documento.open();

        documento.add(getTabelaDadosGeraisGuia(guia));
        documento.add(getTabelaProcedimentos(guia));
        documento.add(getLinhaEspecialidade(guia));
        if(getLinhaAcrescimos(guia)!=null){
            documento.add(getLinhaAcrescimos(guia));
        }
        documento.add(getTabelaValores(guia));
        documento.add(getTabelaDiferenca(guia));
        documento.add(new Paragraph("\n")); //Linha em Branco
        documento.add(getTabelaAssinaturas(guia));

        documento.close();

        return true;
    }

    private String getLinhaDataHoraEmissao(){
        Calendar calendar = Calendar.getInstance();
        int hora = calendar.get(Calendar.HOUR_OF_DAY);
        int minu = calendar.get(Calendar.MINUTE);
        String linhaEmissao = "Guia emitida em "+dateFormat.format(calendar.getTime())+" �s "+ ((hora < 10 ? "0" + hora : hora + "") + ":" + (minu < 10 ? "0" + minu : minu + ""))+".";
        return linhaEmissao;
    }

    private HeaderFooter getRodapeEmissao() throws Exception {
        Phrase p = new Phrase();
        p.add(new Chunk("_____________________________________________________________________________________________________\n", TIMES_NORMAL_10));
        p.add(new Chunk(getLinhaDataHoraEmissao(), TIMES_NORMAL_10));
        HeaderFooter footer = new HeaderFooter(p, false);
        footer.setBorder(HeaderFooter.NO_BORDER);
        return footer;
    }

    private HeaderFooter getFooter(Guia guia) throws Exception {

        String autorizador = null;
        String solicitante = guia.getToUsuarioAutorizadoSolicita().getNomUsuario();
        try{
            autorizador = guia.getToUsuarioAutorizacaoTRE().getUserName();

        }catch(NullPointerException npe){
            autorizador = "Autoriza��o autom�tica";
        }
        String dataSolicitacao = dateFormat.format(guia.getDataSolicitacaoWeb());
        String dataAutorizacao = dateFormat.format(guia.getDataAutorizacaoTre());

        Phrase p = new Phrase();
        p.add(new Chunk("_____________________________________________________________________________________________________\n", TIMES_NORMAL_10));
        p.add(new Chunk("Data da solicita��o:   ", TIMES_BOLD_10));
        p.add(new Chunk(dataSolicitacao, TIMES_NORMAL_10));
        p.add(new Chunk("                     Solicitante:   ", TIMES_BOLD_10));
        p.add(new Chunk(StringMethods.primeirasLetrasMaiusculas(solicitante)+"\n", TIMES_NORMAL_10));
        p.add(new Chunk("Data da autoriza��o: ", TIMES_BOLD_10));
        p.add(new Chunk(dataAutorizacao, TIMES_NORMAL_10));
        p.add(new Chunk("                    Autorizador: ", TIMES_BOLD_10));
        p.add(new Chunk(StringMethods.primeirasLetrasMaiusculas(autorizador)+"\n", TIMES_NORMAL_10));
        p.add(new Chunk("Justificativa: ", TIMES_BOLD_10));
        p.add(new Chunk(guia.getJustificativa()+"\n", TIMES_NORMAL_10));
        p.add(new Chunk(getLinhaDataHoraEmissao()+"", TIMES_NORMAL_10));

        HeaderFooter footer = new HeaderFooter(p, false);
        footer.setBorder(HeaderFooter.NO_BORDER);
        return footer;
    }

    private void atualizarDadosGuia(Guia guia, DataContext context,HttpServletRequest req) throws ServletException{
        try{
            Calendar calEmissao = Calendar.getInstance();
            calEmissao.set(Calendar.HOUR_OF_DAY, 0);
            calEmissao.set(Calendar.MINUTE, 0);
            calEmissao.set(Calendar.SECOND, 0);
            calEmissao.set(Calendar.MILLISECOND, 0);
            Date datEmissao = calEmissao.getTime();

            Situacao situacao = (Situacao) DataObjectUtils.objectForPK(context, Situacao.class, Situacao.SITUACAO_EM_ABERTO);

            UsuarioAutorizado usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, req.getRemoteUser());

            guia.setDatEmissao(datEmissao);
            guia.setToSituacao(situacao);
            guia.setToUsuarioAutorizado(usuarioAutorizado);
            context.commitChanges();
        }catch(Exception e){
            context.rollbackChanges();
            throw new ServletException("<br/><br/>A Situa��o da Guia n�o foi alterada para EM ABERTO.<br/>A Data de Emiss�o da Guia n�o foi atualizada.", e);
        }
    }

    private Paragraph getTabelaDadosGeraisGuia(Guia guia) throws BadElementException, DocumentException, NamingException, Exception{
        Calendar calDatValidade = Calendar.getInstance();
        calDatValidade.setTime(guia.getDatEmissao());
        calDatValidade.add(Calendar.DAY_OF_MONTH, (Integer) Util.getEnvVariable("numDiaValidade"));
        String credenciado = guia.getToCredenciado().getToInstituicao().getNomInstituicao();
        String titular = guia.getToBeneficiario().getToTitular().getMatNomeTipoDep();
        String funcao = guia.getToSituacaoFuncional().getNomSitFunc();
        String paciente = guia.getToBeneficiario().getMatNomeTipoDep();
        String num_guia = guia.getNumAnoGuia();
        String emissao = dateFormat.format(guia.getDatEmissao());
        String validade = dateFormat.format(calDatValidade.getTime());

        paragrafoTemp = new Paragraph();
        tabelaTemp = new Table(4, 4);//4 colunas e 4 linhas
        tabelaTemp.setWidth(100);
        tabelaTemp.setWidths(new int[]{15, 60, 12, 13}); //largura das coluna
        tabelaTemp.setBorder(SEM_BORDA);

        celulaTemp = new Cell();
        celulaTemp.add(new Chunk("Credenciado:", RelatorioPDF.TIMES_BOLD_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);
        celulaTemp = new Cell();
        celulaTemp.add(new Chunk(credenciado, RelatorioPDF.TIMES_NORMAL_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.add(new Chunk("N� Guia:", RelatorioPDF.TIMES_BOLD_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);
        celulaTemp = new Cell();
        celulaTemp.add(new Chunk(num_guia, RelatorioPDF.TIMES_NORMAL_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.add(new Chunk("Titular:", RelatorioPDF.TIMES_BOLD_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);
        celulaTemp = new Cell();
        celulaTemp.add(new Chunk(titular, RelatorioPDF.TIMES_NORMAL_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.add(new Chunk("Emiss�o:", RelatorioPDF.TIMES_BOLD_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);
        celulaTemp = new Cell();
        celulaTemp.add(new Chunk(emissao, RelatorioPDF.TIMES_NORMAL_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.add(new Chunk("Fun��o:", RelatorioPDF.TIMES_BOLD_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);
        celulaTemp = new Cell();
        celulaTemp.add(new Chunk(funcao, RelatorioPDF.TIMES_NORMAL_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.add(new Chunk("Validade:", RelatorioPDF.TIMES_BOLD_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);
        celulaTemp = new Cell();
        celulaTemp.add(new Chunk(validade, RelatorioPDF.TIMES_BOLD_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.add(new Chunk("Paciente:", RelatorioPDF.TIMES_BOLD_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);
        celulaTemp = new Cell();
        celulaTemp.add(new Chunk(paciente, RelatorioPDF.TIMES_NORMAL_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);

        paragrafoTemp.add(tabelaTemp);
        return paragrafoTemp;
    }

    private Paragraph getTabelaProcedimentos(Guia guia) throws BadElementException, DocumentException, NamingException{
        //TABELA PROCEDIMENTOS
        paragrafoTemp = new Paragraph();
        tabelaTemp = new Table(6);  //n�mero de colunas
        tabelaTemp.setWidth(100);
        tabelaTemp.setPadding(CELL_PADDING);
        tabelaTemp.setWidths(new int[]{60, 7, 5, 5, 4, 9}); //largura das coluna

        // Linha de Cabe�alho
        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("P R O C E D I M E N T O", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("R$ Unid", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("Via", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("V�deo", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("Qtd", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("Valor (R$)", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
        tabelaTemp.addCell(celulaTemp);

        
        String codConsulta = (String)Util.getEnvVariable("codProcedimentoConsulta");
        for (GuiaProcedimento guiaProcedimento: guia.getGuiaProcedimentoArray()) {
            String viaAcesso = guiaProcedimento.getViaAcesso() ? "Sim" : "";
            String video = guiaProcedimento.getVideo() ? "Sim" : "";

            if(guiaProcedimento.getToProcedimento().getCodProcedimento().equals(codConsulta)){
                valorConsultasUrgentes = guiaProcedimento.getQtde() * guiaProcedimento.getValor();
            }

            //   |-->Procedimento  
            celulaTemp = new Cell();
            celulaTemp.add(new Chunk(guiaProcedimento.getToProcedimento().getCodNomProcedimento(), RelatorioPDF.TIMES_NORMAL_10));
            celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
            tabelaTemp.addCell(celulaTemp);
            //   |-->R$ Unid
            celulaTemp = new Cell();
            celulaTemp.add(new Chunk(decimalFormat.format(guiaProcedimento.getValor()), RelatorioPDF.TIMES_NORMAL_10));
            celulaTemp.setHorizontalAlignment(Cell.ALIGN_RIGHT);
            tabelaTemp.addCell(celulaTemp);
            //   |-->Via
            celulaTemp = new Cell();
            celulaTemp.add(new Chunk(viaAcesso, RelatorioPDF.TIMES_NORMAL_10));
            celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
            tabelaTemp.addCell(celulaTemp);
            //   |-->Video
            celulaTemp = new Cell();
            celulaTemp.add(new Chunk(video, RelatorioPDF.TIMES_NORMAL_10));
            celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
            tabelaTemp.addCell(celulaTemp);
            //   |-->Qtd
            celulaTemp = new Cell();
            celulaTemp.add(new Chunk(guiaProcedimento.getQtde().toString(), RelatorioPDF.TIMES_NORMAL_10));
            celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
            tabelaTemp.addCell(celulaTemp);
            //   |-->Valor (R$)
            celulaTemp = new Cell();
            celulaTemp.add(new Chunk(decimalFormat.format(guiaProcedimento.getValorcalc()), RelatorioPDF.TIMES_NORMAL_10));
            celulaTemp.setHorizontalAlignment(Cell.ALIGN_RIGHT);
            tabelaTemp.addCell(celulaTemp);
        }
        paragrafoTemp.add(tabelaTemp);
        return paragrafoTemp;
    }

    public Paragraph getLinhaEspecialidade(Guia guia){
        String especialidade = "N�O TEM";
        if (guia.getToEspecialidade() != null) {especialidade = guia.getToEspecialidade().getNomEspecialidade();}
        paragrafoTemp = new Paragraph();
        chunkTemp = new Chunk("Especialidade: ", RelatorioPDF.TIMES_BOLD_10);
        paragrafoTemp.add(chunkTemp);
        chunkTemp = new Chunk(especialidade+"\n", RelatorioPDF.TIMES_NORMAL_10);
        paragrafoTemp.add(chunkTemp);
        return paragrafoTemp;
    }

    public Paragraph getLinhaAcrescimos(Guia guia) throws NamingException{
        paragrafoTemp = null;
        String acrescimos_referentes = "";
        if (guia.getIndUrgencia() || guia.getIndInternacao() || guia.getIndApartamento()) {
            acrescimos_referentes += "Acr�scimos Referentes a:";
            if (guia.getIndUrgencia()) {
                double percUrgencia = (Double)Util.getEnvVariable("percAcrescimoUrgencia");
                acrescimos_referentes += " Urg�ncia ("+percUrgencia+"% apenas sobre o valor de consultas),";}
            if (guia.getIndInternacao()) {acrescimos_referentes += " Interna��o,";}
            if (guia.getIndApartamento()) {acrescimos_referentes += " Apartamento,";}
            if (acrescimos_referentes.endsWith(",")){acrescimos_referentes = acrescimos_referentes.substring(0, acrescimos_referentes.length()-1);}
        }
        if(!acrescimos_referentes.trim().equals("")){
            paragrafoTemp = new Paragraph();
            chunkTemp = new Chunk(acrescimos_referentes, RelatorioPDF.TIMES_NORMAL_10);
            paragrafoTemp.add(chunkTemp);
        }
        return paragrafoTemp;
    }

    public Paragraph getTabelaValores(Guia guia) throws BadElementException, DocumentException, NamingException{
        double somaValor = 0.0;
        double acrescimoUrgencia = 0.0;
        double acrescimoApartamento = 0.0;

        for (GuiaProcedimento guiaProcedimento: guia.getGuiaProcedimentoArray()) {
            somaValor += guiaProcedimento.getValorcalc();
        }

        //O acr�scimo de urg�ncia recai apenas sobre o procedimento CONSULTA (segundo a F�bia em jan.2010)
        if (guia.getIndUrgencia()) {
            acrescimoUrgencia = valorConsultasUrgentes * (Double)Util.getEnvVariable("percAcrescimoUrgencia") / 100;
        }
        if (guia.getIndApartamento() || guia.getIndInternacao()) {
            acrescimoApartamento = somaValor * (Double)Util.getEnvVariable("percAcrescimoApIntern") / 100;
        }

        double acrescimos = acrescimoUrgencia + acrescimoApartamento;
        double parcServ = guia.getTotal() * guia.getCusteio() / 100;
        double parcTre = guia.getTotal() * (100 - guia.getCusteio()) / 100;

        String str_acrescimos = decimalFormat.format(acrescimos);
        String str_parcServ = decimalFormat.format(parcServ);
        String str_parcTRE = decimalFormat.format(parcTre);
        String str_total = decimalFormat.format(guia.getTotal());

        //TABELA Valores
        paragrafoTemp = new Paragraph();
        tabelaTemp = new Table(2);  //n�mero de colunas
        tabelaTemp.setWidth(100);
        tabelaTemp.setPadding(CELL_PADDING);
        tabelaTemp.setWidths(new int[]{90,10}); //largura das coluna
        tabelaTemp.setBorder(SEM_BORDA);

        celulaTemp = new Cell();
        celulaTemp.add(new Chunk("Acr�scimos R$:", RelatorioPDF.TIMES_BOLD_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_RIGHT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);
        celulaTemp = new Cell();
        celulaTemp.add(new Chunk(str_acrescimos, RelatorioPDF.TIMES_NORMAL_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_RIGHT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.add(new Chunk("Parc. Serv. R$:", RelatorioPDF.TIMES_BOLD_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_RIGHT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);
        celulaTemp = new Cell();
        celulaTemp.add(new Chunk(str_parcServ, RelatorioPDF.TIMES_NORMAL_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_RIGHT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.add(new Chunk("Parc. TRE R$:", RelatorioPDF.TIMES_BOLD_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_RIGHT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);
        celulaTemp = new Cell();
        celulaTemp.add(new Chunk(str_parcTRE, RelatorioPDF.TIMES_NORMAL_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_RIGHT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.add(new Chunk("TOTAL R$:", RelatorioPDF.TIMES_BOLD_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_RIGHT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);
        celulaTemp = new Cell();
        celulaTemp.add(new Chunk(str_total, RelatorioPDF.TIMES_NORMAL_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_RIGHT);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);

        paragrafoTemp.add(tabelaTemp);
        return paragrafoTemp;
    }

    public Paragraph getTabelaDiferenca(Guia guia) throws BadElementException, DocumentException{
        //TABELA Diferen�a
        paragrafoTemp = new Paragraph();
        tabelaTemp = new Table(3);  //n�mero de colunas
        tabelaTemp.setBorder(SEM_BORDA);
        tabelaTemp.setWidth(100);
        tabelaTemp.setPadding(CELL_PADDING);
        tabelaTemp.setWidths(new int[]{62,20,18}); //largura das coluna

        // Linha de Cabe�alho
        celulaTemp = new Cell();
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);
        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.setColspan(2);
        celulaTemp.add(new Chunk("Diferen�a no valor das despesas ap�s faturamento", RelatorioPDF.TIMES_NORMAL_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);
        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("Valor faturado", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        tabelaTemp.addCell(celulaTemp);
        tabelaTemp.addCell(new Cell());

        celulaTemp = new Cell();
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);
        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("Parcela do Servidor", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        tabelaTemp.addCell(celulaTemp);
        tabelaTemp.addCell(new Cell());

        celulaTemp = new Cell();
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);
        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("Parcela do TRE-DF", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
        tabelaTemp.addCell(celulaTemp);
        tabelaTemp.addCell(new Cell());

        paragrafoTemp.setAlignment(Paragraph.ALIGN_RIGHT);
        paragrafoTemp.add(tabelaTemp);
        return paragrafoTemp;
    }

    private Paragraph getTabelaAssinaturas(Guia guia) throws BadElementException, DocumentException, NamingException, Exception{
        String nome = null;
        String emissor = null;
        if(guia.getToUsuarioAutorizado()!=null){
            nome = guia.getToUsuarioAutorizado().getNomUsuario();
            emissor = guia.getToUsuarioAutorizado().getToCredenciadoAutorizado().getToCredenciado().getToInstituicao().getNomInstituicao();
        } else {
            nome = "Imposs�vel recuperar Usu�rio";
            emissor = "Imposs�vel recuperar Emissor";
        }
        
        //TABELA Assinaturas
        paragrafoTemp = new Paragraph();
        tabelaTemp = new Table(2);  //n�mero de colunas
        tabelaTemp.setWidth(100);
        tabelaTemp.setPadding(CELL_PADDING);
        tabelaTemp.setBorder(SEM_BORDA);
        tabelaTemp.setWidths(new int[]{55,45}); //largura das coluna

        celulaTemp = new Cell();
        celulaTemp.add(new Chunk("__________________________________________________\n"+nome+"\n"+emissor, RelatorioPDF.TIMES_BOLD_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.add(new Chunk("__________________________________________________\nCI�NCIA DO BENEFICI�RIO", RelatorioPDF.TIMES_BOLD_9));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
        celulaTemp.setBorder(SEM_BORDA);
        tabelaTemp.addCell(celulaTemp);

        paragrafoTemp.add(tabelaTemp);
        return paragrafoTemp;
    }
    private UsuarioAutorizado getUsuarioAutorizado(DataContext context){        
        return (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, codUsuarioLogado);     
    }

  
}
