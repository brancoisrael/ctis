package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._Procedimento;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.DataRow;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SQLTemplate;
import org.apache.cayenne.query.SelectQuery;

public class Procedimento extends _Procedimento {
        public String getCodProcedimento() {
        return (getObjectId() != null && !getObjectId().isTemporary())
                ? (String) getObjectId().getIdSnapshot().get(COD_PROCEDIMENTO_PK_COLUMN)
                : null;
    }

    public String getCodNomProcedimento() {
        String retorno = "";
        retorno += getCodProcedimento();
        retorno += " - ";
        retorno += getNomProcedimento();
        return retorno;
    }

    public boolean getEhProcedimentoAutorizado() {
        try {
            this.getToProcedimentoAutorizado().getDatUltAtual().toString();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public String getEhProcedimentoAutorizadoFormatado() {
        if (getEhProcedimentoAutorizado()) {
            return "autorizado";
        } else {
            return "restrito";
        }
    }
    
    public boolean getEhProcedimentoAtivo() {
        if(this.getProcedimentoAtivo()==0){
            return true;
        }else{
            return false;
        }
    }

    public List<Procedimento> recuperarListaProcedimentosTipoConsulta(Integer cod_tabela, DataContext context) {

        Expression exp = ExpressionFactory.matchDbExp(Procedimento.COD_TABELA_PK_COLUMN, cod_tabela);
        exp = exp.andExp(ExpressionFactory.matchExp(Procedimento.CONSULTA_PROPERTY, 1));

        SelectQuery select = new SelectQuery(Procedimento.class, exp);
        List<Procedimento> lista = context.performQuery(select);

        return lista;
    }
    
    public String getDataCarenciaProcedimentoPorPaciente(DataContext context, String matServidor, String codDepend, String codProcedimento, Integer codTabela){
        Date dataCarencia = null;
        Date dataHoje = new Date();
        
        if(codDepend == null || codDepend.trim().equals("")){
            codDepend = "0";
        }
        
        String sql = "select fc_retorna_carencia('M', '" + matServidor + "' ," + codDepend + ", " + codProcedimento + " , " + codTabela + " ) dt_carencia from dual";
        
        SQLTemplate sqlTemp = new SQLTemplate(Procedimento.class, sql);
        sqlTemp.setFetchingDataRows(true);
        List<DataRow> drResultado = context.performQuery(sqlTemp);

        for (DataRow dr : drResultado) {
            dataCarencia = (Date) dr.get("DT_CARENCIA");
        }
        
        if(dataCarencia.before(dataHoje)){
            return "sem car�ncia";
        }else{
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            return dateFormat.format(dataCarencia);
        }
    }
    
    public Procedimento recuperarProcedimento(DataContext context, Integer codTabela, String codProcedimento) {
        Map<String, Object> mapPk = new HashMap<String, Object>();
        mapPk.put(Procedimento.COD_PROCEDIMENTO_PK_COLUMN, codProcedimento);
        mapPk.put(Procedimento.COD_TABELA_PK_COLUMN, codTabela);
        Procedimento procedimento = (Procedimento) DataObjectUtils.objectForPK(context, Procedimento.class, mapPk);
        if (procedimento == null) {
            return null;
        } else {
            return procedimento;
        }
    }
    
    // Recupera os procedimentos de consulta para verificar o prazo de car�ncia para emissao de guias de despesas m�dicas de urg�ncia.
    public Procedimento recuperarProcedimentoConsulta(DataContext context, UsuarioAutorizado usuarioAutorizado) {
        Procedimento p = null;
        
        // select * from procedimento t where t.cod_especialidade=0 and t.requer_especialidade=1 and t.cod_tabela=14
        Expression exp = null;
        exp = ExpressionFactory.matchExp(Procedimento.COD_ESPECIALIDADE_PROPERTY, 0);
        exp = exp.andExp(ExpressionFactory.matchExp(Procedimento.REQUER_ESPECIALIDADE_PROPERTY, 1));
        exp = exp.andExp(ExpressionFactory.matchDbExp(Procedimento.COD_TABELA_PK_COLUMN, usuarioAutorizado.getToCredenciadoAutorizado().getToCredenciado().getToTabela().getCodTabela()));

        SelectQuery select = new SelectQuery(Procedimento.class, exp);
        List<Procedimento> lista = context.performQuery(select);

        if(lista!=null && !lista.isEmpty()){
            for (Procedimento procedimento: lista) {
                p = procedimento;
            }
        }
        
        return p;
    }
  
}
