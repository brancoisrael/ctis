package br.gov.tredf.tresaudeAdm.utils;

import java.util.Calendar;
import java.util.Date;

/**
 * @author Camila Kinoshita
 */

public class DataUtil {

    public DataUtil() {
        Calendar calendar = Calendar.getInstance();
        this.geraArraysFeriados(calendar.get(Calendar.YEAR));
    }

    // arrays que recebem todos os feriados nacionais do ano!!! XD
    // 9 feriados fixos e 3 m�veis
    private int[] arrayDiasFeriado =  {1, 21, 1, 7, 12,  2, 15, 25, 30, 31, 0, 0, 0};
    private int[] arrayMesesFeriado = {1,  4, 5, 9, 10, 11, 11, 12, 11, 12, 0, 0, 0};

    // Recebe o dia a ser analisado em milisegundos e os arrays de dia e mes dos feriados
    public boolean ehDiaUtil(long millis) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(millis);

        if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
            return false;
        } else {
            int dia = calendar.get(Calendar.DAY_OF_MONTH);
            int mes = calendar.get(Calendar.MONTH) + 1;
            for (int i = 0; i < arrayDiasFeriado.length; i++) {
                if (arrayDiasFeriado[i] == dia && arrayMesesFeriado[i] == mes) {
                    return false;
                }
            }
        }
        return true;
    }

    // Completa os arrays de dia e mes dos feriados
    // Recebe tamb�m o ano para o c�lculo dos feriados m�veis
    private void geraArraysFeriados(int ano) {

        final long day = 24 * 60 * 60 * 1000;
        Calendar calendar = Calendar.getInstance();

        Date pascoa = getPascoaAno(ano);
        long pascoam = pascoa.getTime();

        // feri�dos m�veis
        Date tercaCarnaval = new Date(pascoam - 48 * day);
        Date sextaSanta = new Date(pascoam - 4 * day);
        Date corpusChristi = new Date(pascoam + 60 * day);

        int i = 9;

        calendar.setTime(tercaCarnaval);
        arrayDiasFeriado[i] = calendar.get(Calendar.DAY_OF_MONTH);
        arrayMesesFeriado[i] = calendar.get(Calendar.MONTH) + 1;
        i++;

        calendar.setTime(sextaSanta);
        arrayDiasFeriado[i] = calendar.get(Calendar.DAY_OF_MONTH);
        arrayMesesFeriado[i] = calendar.get(Calendar.MONTH) + 1;
        i++;

        calendar.setTime(corpusChristi);
        arrayDiasFeriado[i] = calendar.get(Calendar.DAY_OF_MONTH);
        arrayMesesFeriado[i] = calendar.get(Calendar.MONTH) + 1;
    }

    // Calcula a data da p�scoa no ano
    // Testei at� 2038 e acertou todos :)
    private Date getPascoaAno(int a) {
        int c = a / 100;
        int n = a - (19 * (a / 19));
        int k = (c - 17) / 25;
        int i = c - c / 4 - ((c - k) / 3) + (19 * n) + 15;
        i = i - (30 * (i / 30));
        i = i - ((i / 28) * (1 - (i / 28)) * (29 / (i + 1)) * ((21 - n) / 11));
        int j = a + a / 4 + i + 2 - c + c / 4;
        j = j - (7 * (j / 7));
        int l = i - j;
        int m = 3 + ((l + 40) / 44);
        int d = l + 28 - (31 * (m / 4));

        Calendar calendar = Calendar.getInstance();
        // Thu Jan 01 00:00:00 GMT-03:00 1970
        calendar.setTimeInMillis(3 * 60 * 60 * 1000);
        calendar.set(Calendar.DAY_OF_MONTH, d);
        calendar.set(Calendar.MONTH, m - 1);
        calendar.set(Calendar.YEAR, a);
        Date pascoa = calendar.getTime();

        return pascoa;
    }

}
