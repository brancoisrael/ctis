/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.servlet.senha;

import br.gov.tredf.tresaudeAdm.bean.CredenciadoAutorizado;
import br.gov.tredf.tresaudeAdm.utils.CriptoMD5;
import java.security.NoSuchAlgorithmException;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServlet;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;

/**
 *
 * @author marconde
 */
public class MudaSenhaDeTesteMain extends HttpServlet{
//    public static void main(String[] args){
//        
//        String senha="12345";
//        try {
//            String saida = CriptoMD5.cripto(senha);
//            System.out.println(saida);
//        } catch (NoSuchAlgorithmException ex) {
//            Logger.getLogger(MudaSenhaDeTesteMain.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        
//        
//    }
}
