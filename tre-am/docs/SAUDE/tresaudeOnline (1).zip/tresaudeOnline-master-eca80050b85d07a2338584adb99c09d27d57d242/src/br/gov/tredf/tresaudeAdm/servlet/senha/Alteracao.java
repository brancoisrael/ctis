/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.gov.tredf.tresaudeAdm.servlet.senha;

import br.gov.tredf.tresaudeAdm.bean.CredenciadoAutorizado;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import br.gov.tredf.tresaudeAdm.utils.CriptoMD5;
import java.io.IOException;
import java.util.Calendar;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;

/**
 *
 * @author igor
 */
public class Alteracao extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
                String titulo = "Senha alterada com sucesso";
        req.setAttribute("titulo", titulo);

        String senha = null;
        String confirmacaoSenha = null;

        senha = req.getParameter("senha");
        confirmacaoSenha = req.getParameter("confirmacaoSenha");

        if (senha == null || senha.equals("")) {
            throw new ServletException("Senha � campo obrigat�rio");
        }

        if (confirmacaoSenha == null || confirmacaoSenha.equals("")) {
            throw new ServletException("Confirma��o de senha � campo obrigat�rio");
        }

        if (!senha.equals(confirmacaoSenha)) {
            throw new ServletException("Confirma��o de senha deve ser igual � senha");
        }

        DataContext context = ServletUtil.getSessionContext(req.getSession());

        Integer codCredenciado = new Integer(req.getRemoteUser());
        
        try {
            CredenciadoAutorizado credenciado = (CredenciadoAutorizado) DataObjectUtils.objectForPK(context, CredenciadoAutorizado.class, codCredenciado);
            credenciado.setSenhaMd5(CriptoMD5.cripto(senha));
            credenciado.setSenhaMd5Login(CriptoMD5.cripto(senha));
            credenciado.setDatUltAtual(Calendar.getInstance().getTime());
            context.commitChanges();
        } catch (Exception e) {
            context.rollbackChanges();
            throw new ServletException(e);
        }

        RequestDispatcher view = req.getRequestDispatcher("/restrita/adm/senha/sucesso.jsp");
        view.forward(req, resp);
    }
    
}
