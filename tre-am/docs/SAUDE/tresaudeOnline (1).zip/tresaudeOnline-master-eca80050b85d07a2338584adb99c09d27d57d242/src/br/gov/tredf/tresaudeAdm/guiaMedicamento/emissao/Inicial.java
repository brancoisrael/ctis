/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.guiaMedicamento.emissao;


import br.gov.tredf.tresaudeAdm.bean.Procedimento;

import br.gov.tredf.tresaudeAdm.bean.TipoGuia;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import br.gov.tredf.tresaudeAdm.utils.Util;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;

/**
 * @author Camila Kinoshita
 */
public class Inicial extends HttpServlet {
@Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String titulo = "Emiss�o de Guia de Despesas Atendimento de Urg�ncia";
        req.setAttribute("titulo", titulo);

        String descricao = "Taxas, materiais, medicamentos e exames. Valor estimativo a ser conferido com a conta anal�tica.";
        req.setAttribute("descricao", descricao);

        String codUsuario = req.getRemoteUser();

        if (codUsuario == null || codUsuario.equals("")) {
            throw new ServletException("C�digo do usu�rio est� com o valor nulo ou em branco.");
        }

        DataContext context = ServletUtil.getSessionContext(req.getSession());

        TipoGuia tipoGuia = (TipoGuia) DataObjectUtils.objectForPK(context, TipoGuia.class, TipoGuia.GUIA_MEDICA_CIRURGICA_HOSPITALAR);
        req.setAttribute("tipoGuia", tipoGuia);

        UsuarioAutorizado usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, codUsuario);
        req.setAttribute("usuarioAutorizado", usuarioAutorizado);
        
        Integer codTabela = usuarioAutorizado.getToCredenciadoAutorizado().getToCredenciado().getToTabela().getCodTabela();
        
        this.recuperarProcedimentoConsulta(req, codTabela, context);
        this.buscaPercentuaisAcrescimo(req);
        this.buscaValorPadraoGuia(req);

        RequestDispatcher view = req.getRequestDispatcher("/restrita/user/guiaMedicamento/emissao/emissao.jsp");
        view.forward(req, resp);
    }

    private void buscaPercentuaisAcrescimo(HttpServletRequest req) throws ServletException{
        try {
            Double percApartamento = (Double) Util.getEnvVariable("percAcrescimoApIntern") / 100;
            //Double percApartamento = (Double) 0.3;
            req.setAttribute("percAcrescimoApartamento", percApartamento);
            Double percInternacao = (Double) Util.getEnvVariable("percAcrescimoApIntern") / 100;
            //Double percInternacao = (Double) 0.3;
            req.setAttribute("percAcrescimoInternacao", percInternacao);

        } catch (Exception ex) {
            throw new ServletException("TreSaudeUser guiaMedicamento.emissao.inicial.buscaPercentuaisAcrescimo(). Erro ao recuperar percentuais de acrescimos.\n", ex);
        }
    }

    private void buscaValorPadraoGuia(HttpServletRequest req) throws ServletException{
        try {
            String valorGuiaMedicamento = (String) Util.getEnvVariable("valorGuiaMedicamento");
            req.setAttribute("valor", valorGuiaMedicamento);
        } catch (Exception ex) {
            throw new ServletException("TreSaudeUser GuiaMedicamento.Emissao.buscaValorPadraoGuia(). Erro ao recuperar valor da guia.\n", ex);
        }
    }


    private void recuperarProcedimentoConsulta(HttpServletRequest req, Integer cod_tabela, DataContext context) {
        
        // select * from procedimento t where t.cod_especialidade=0 and t.requer_especialidade=1 and t.cod_tabela=14
        Expression exp = null;
        exp = ExpressionFactory.matchExp(Procedimento.COD_ESPECIALIDADE_PROPERTY, 0);
        exp = exp.andExp(ExpressionFactory.matchExp(Procedimento.REQUER_ESPECIALIDADE_PROPERTY, 1));
        exp = exp.andExp(ExpressionFactory.matchDbExp(Procedimento.COD_TABELA_PK_COLUMN, cod_tabela));
        
        SelectQuery select = new SelectQuery(Procedimento.class, exp);
        List<Procedimento> lista = context.performQuery(select);

        if(lista!=null && !lista.isEmpty()){
            DecimalFormat decimalFormat = new DecimalFormat("###,##0.00");
            
            for (Procedimento procedimento: lista) {
                String codProcedimentoConsulta = procedimento.getCodProcedimento().toString();
                String nomProcedimentoConsulta = procedimento.getNomProcedimento();
                String valorProcedimentoConsulta = decimalFormat.format(procedimento.getValorProcedimento());
                String requerEspecialidadeConsulta = procedimento.getRequerEspecialidade().toString();
                req.setAttribute("codProcedimentoConsulta", codProcedimentoConsulta);
                req.setAttribute("nomProcedimentoConsulta", nomProcedimentoConsulta);
                req.setAttribute("valorProcedimentoConsulta", valorProcedimentoConsulta);
                req.setAttribute("requerEspecialidadeConsulta", requerEspecialidadeConsulta);
            }
        }
    }
}    