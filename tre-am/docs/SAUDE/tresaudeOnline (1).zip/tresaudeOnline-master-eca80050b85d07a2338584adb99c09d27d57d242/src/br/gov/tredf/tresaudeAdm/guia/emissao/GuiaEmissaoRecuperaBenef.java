/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.guia.emissao;

import br.gov.tredf.tresaudeAdm.bean.Beneficiario;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;

/**
 *
 * @author igor
 */
public class GuiaEmissaoRecuperaBenef extends HttpServlet {

    
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String matServidor = req.getParameter("matServidor");
        if ((matServidor != null) && (!matServidor.equals(""))) {
            DataContext context = ServletUtil.getSessionContext(req.getSession());

            Expression expBeneficiario = ExpressionFactory.matchDbExp(Beneficiario.MAT_SERVIDOR_PK_COLUMN, matServidor);
            expBeneficiario = expBeneficiario.andExp(ExpressionFactory.matchExp(Beneficiario.EXCLUIDO_PROPERTY, "N"));
            SelectQuery queryBeneficiario = new SelectQuery(Beneficiario.class, expBeneficiario);
            List<Beneficiario> listBeneficiario = context.performQuery(queryBeneficiario);
            if (listBeneficiario != null && (!listBeneficiario.isEmpty())) {
                String dados = "";
                int cont = 0;
                for (Beneficiario beneficiario : listBeneficiario) {
                    cont++;
                    
                    if (beneficiario.getCodDepend() != null) {
                        dados += beneficiario.getCodDepend().toString();
                    } else {
                        dados += "0";
                    }
                    dados += "\\#";

                    if (beneficiario.getNome() != null) {
                        dados += beneficiario.getNome();
                    }

                    if (cont < listBeneficiario.size()) {
                        dados += "\\n";
                    }
                }
                resp.setContentType("text/html");
                resp.getWriter().write(dados);
            } else {
                resp.getWriter().write("");
            }
        }
    }
}
