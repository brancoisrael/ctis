package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._TipoGuia;

public class TipoGuia extends _TipoGuia {
    public static final int GUIA_MEDICA_CLINICA_LABORATORIAL = 1;
    // O tipo 2 na verdade � GUIA_MEDICA_DESPESA_URGENCIA_SEM_INTERNACAO
    public static final int GUIA_MEDICA_CIRURGICA_HOSPITALAR = 11;
    public static final int GUIA_MEDICA_CONSULTA = 10;
    public static final int ANTIGA_GUIA_MEDICA_CIRURGICA_HOSPITALAR = 2;

    public Integer getCodTipGuia() {
        return (getObjectId() != null && !getObjectId().isTemporary())
            ? (Integer)getObjectId().getIdSnapshot().get(COD_TIP_GUIA_PK_COLUMN)
            : null;
    }
    
    public static Object[] getTiposDeGuia(){
        Object[] tipoGuiaValues = {
            TipoGuia.GUIA_MEDICA_CLINICA_LABORATORIAL,
            TipoGuia.GUIA_MEDICA_CIRURGICA_HOSPITALAR,
            TipoGuia.GUIA_MEDICA_CONSULTA,
            TipoGuia.ANTIGA_GUIA_MEDICA_CIRURGICA_HOSPITALAR
        };
        
        return tipoGuiaValues;
    }
    
}
