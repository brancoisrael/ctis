package br.gov.tredf.tresaudeAdm.servlet.relatorio.periodo;

import br.gov.tredf.tresaudeAdm.bean.Guia;
import br.gov.tredf.tresaudeAdm.bean.OrigemGuia;
import br.gov.tredf.tresaudeAdm.bean.Credenciado;
import br.gov.tredf.tresaudeAdm.bean.CredenciadoAutorizado;
import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfWriter;
import java.io.*;
import br.gov.tredf.tresaudeAdm.relatorioPDF.RelatorioPDF;
import br.gov.tredf.tresaudeAdm.utils.StringMethods;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Calendar;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;

/**
 * @author Eneias
 */
public class Impressao extends RelatorioPDF {

    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    DecimalFormat decimalFormat = new DecimalFormat("###,##0.00");

    public synchronized boolean imprime(HttpServletRequest req, HttpServletResponse resp, ByteArrayOutputStream pBaos) throws DocumentException, BadElementException, Exception {

        String codCredenciado = req.getParameter("codCredenciado");
        Calendar calDtInicial = Calendar.getInstance();
        Calendar calDtFinal = Calendar.getInstance();
        calDtFinal.set(Calendar.MILLISECOND, 999);

        // data inicial da pesquisa
        if (req.getParameter("dtInicial") != null) {
            if (!req.getParameter("dtInicial").equals("")) {
                String dtInicial = req.getParameter("dtInicial");
                calDtInicial.set(Integer.parseInt(dtInicial.split("/")[2]), Integer.parseInt(dtInicial.split("/")[1]) - 1, Integer.parseInt(dtInicial.split("/")[0]), 0, 0, 0);
                calDtInicial.set(Calendar.MILLISECOND, 0);
            }
        }
        // data final da pesquisa
        if (req.getParameter("dtFinal") != null) {
            if (!req.getParameter("dtFinal").equals("")) {
                String dtFinal = req.getParameter("dtFinal");
                calDtFinal.set(Integer.parseInt(dtFinal.split("/")[2]), Integer.parseInt(dtFinal.split("/")[1]) - 1, Integer.parseInt(dtFinal.split("/")[0]), 23, 59, 59);
                calDtFinal.set(Calendar.MILLISECOND, 999);
            }

        }
        // verificando o codigo do usu�rio.
        if (codCredenciado == null || codCredenciado.equals("")) {
            throw new ServletException("C�digo do usu�rio est� com o valor nulo ou em branco.");
        }

        DataContext context = ServletUtil.getSessionContext(req.getSession());
        Expression exp = null;

        CredenciadoAutorizado credenciadoAutorizado = (CredenciadoAutorizado) DataObjectUtils.objectForPK(context, CredenciadoAutorizado.class, codCredenciado);
        Credenciado credenciado = credenciadoAutorizado.getToCredenciado();
        exp = ExpressionFactory.matchExp(Guia.TO_CREDENCIADO_PROPERTY, credenciado);
        exp = exp.andExp(ExpressionFactory.matchExp(Guia.TO_ORIGEM_GUIA_PROPERTY, OrigemGuia.GUIAS_ON_LINE));
        exp = exp.andExp(ExpressionFactory.noMatchExp(Guia.TO_USUARIO_AUTORIZADO_PROPERTY, null));
        exp = exp.andExp(ExpressionFactory.betweenExp(Guia.DAT_EMISSAO_PROPERTY, calDtInicial.getTime(), calDtFinal.getTime()));
        SelectQuery select = new SelectQuery(Guia.class, exp);
        select.addOrdering(Guia.DAT_EMISSAO_PROPERTY, true);
        select.addOrdering("db:" + Guia.NUM_GUIA_PK_COLUMN, true);
        List<Guia> lista = context.performQuery(select);

        String siglaCredenciado = credenciado.getToInstituicao().getNomInstituicao();

        String nomeRelatorio = siglaCredenciado + "\nGuias Emitidas entre " + dateFormat.format(calDtInicial.getTime()) + " e " + dateFormat.format(calDtFinal.getTime());
//=======================================================================
        Document documento = new Document(PageSize.A4.rotate(), 40, 40, 6, 30);//int marginLeft,   int marginRight,   int marginTop,   int marginBottom

        PdfWriter pdf = PdfWriter.getInstance(documento, pBaos);
        documento.setHeader(this.getConteudoCabecalho(nomeRelatorio));
        documento.setFooter(this.getConteudoRodape());
        documento.open();
        documento.add(getTabelaGuias(lista));       
        documento.close();
        return true;
    }

    private Paragraph getTabelaGuias(List<Guia> lista) throws BadElementException, DocumentException, Exception {
        Paragraph paragrafoTemp = null;
        Table tabelaTemp = null;
        Cell celulaTemp = null;

        //TABELA PROCEDIMENTOS
        paragrafoTemp = new Paragraph();
        tabelaTemp = new Table(7);  //n�mero de colunas
        tabelaTemp.setWidth(100);
        tabelaTemp.setPadding(1f);
        tabelaTemp.setWidths(new int[]{8, 21, 21, 21, 10, 9, 9}); //largura das coluna

        // Linha de Cabe�alho
        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("MATR.", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
        celulaTemp.setVerticalAlignment(Cell.ALIGN_MIDDLE);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("BENEFICIARIO TITULAR", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
        celulaTemp.setVerticalAlignment(Cell.ALIGN_MIDDLE);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("PACIENTE", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
        celulaTemp.setVerticalAlignment(Cell.ALIGN_MIDDLE);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("EMISSOR", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
        celulaTemp.setVerticalAlignment(Cell.ALIGN_MIDDLE);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("DATA EMISS�O", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("N� DA GUIA", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.setHeader(true);
        celulaTemp.add(new Chunk("TOTAL (R$)", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
        tabelaTemp.addCell(celulaTemp);

        Double somaTotal = 0d;

        for (Guia guia : lista) {
            celulaTemp = new Cell();
            celulaTemp.add(new Chunk(guia.getToBeneficiario().getToTitular().getMatServidor(), RelatorioPDF.TIMES_NORMAL_10));
            celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
            tabelaTemp.addCell(celulaTemp);

            celulaTemp = new Cell();
            celulaTemp.add(new Chunk(StringMethods.primeirasLetrasMaiusculas(guia.getToBeneficiario().getToTitular().getNome()), RelatorioPDF.TIMES_NORMAL_10));
            celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
            tabelaTemp.addCell(celulaTemp);

            celulaTemp = new Cell();
            celulaTemp.add(new Chunk(StringMethods.primeirasLetrasMaiusculas(guia.getToBeneficiario().getNome()), RelatorioPDF.TIMES_NORMAL_10));
            celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
            tabelaTemp.addCell(celulaTemp);

            celulaTemp = new Cell();
            celulaTemp.add(new Chunk(StringMethods.primeirasLetrasMaiusculas(guia.getToUsuarioAutorizado().getNomUsuario()), RelatorioPDF.TIMES_NORMAL_10));
            celulaTemp.setHorizontalAlignment(Cell.ALIGN_LEFT);
            tabelaTemp.addCell(celulaTemp);

            Calendar cal = Calendar.getInstance();
            cal.setTime(guia.getDatEmissao());
            celulaTemp = new Cell();
            celulaTemp.add(new Chunk(dateFormat.format(guia.getDatEmissao()), RelatorioPDF.TIMES_NORMAL_10));
            celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
            tabelaTemp.addCell(celulaTemp);

            celulaTemp = new Cell();
            celulaTemp.add(new Chunk(guia.getNumAnoGuia(), RelatorioPDF.TIMES_NORMAL_10));
            celulaTemp.setHorizontalAlignment(Cell.ALIGN_CENTER);
            tabelaTemp.addCell(celulaTemp);

            celulaTemp = new Cell();
            celulaTemp.add(new Chunk(decimalFormat.format(guia.getTotal()), RelatorioPDF.TIMES_NORMAL_10));
            celulaTemp.setHorizontalAlignment(Cell.ALIGN_RIGHT);
            tabelaTemp.addCell(celulaTemp);

            somaTotal += guia.getTotal();
        }

        celulaTemp = new Cell();
        celulaTemp.setColspan(6);
        celulaTemp.add(new Chunk("TOTAL: ", RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_RIGHT);
        tabelaTemp.addCell(celulaTemp);

        celulaTemp = new Cell();
        celulaTemp.add(new Chunk(decimalFormat.format(somaTotal), RelatorioPDF.TIMES_BOLD_10));
        celulaTemp.setHorizontalAlignment(Cell.ALIGN_RIGHT);
        tabelaTemp.addCell(celulaTemp);

        paragrafoTemp.add(tabelaTemp);
        return paragrafoTemp;
    }

    public HeaderFooter getConteudoCabecalho(String titulo) throws ServletException {
        try {
            Phrase p = new Phrase();
            Phrase cabecalho = new Phrase();
            cabecalho.add(new Chunk("\nTRIBUNAL REGIONAL ELEITORAL - DF\n", TIMES_BOLD_12));
            cabecalho.add(new Chunk("TRE-Sa�de\n", TIMES_BOLD_12));
            cabecalho.add(new Chunk(titulo, TIMES_BOLD_12));

            Table t = null;
            t = new Table(2, 1);//2 colunas e 1 linha
            t.setWidth(100);
            t.setWidths(new int[]{20, 80}); //largura das coluna
            t.setBorderWidth(0);

            Image brasao = getImagemBrasao();
            if (brasao != null) {
                brasao.scalePercent(70);
                brasao.setAlignment(Image.ALIGN_CENTER);
                Cell c1 = new Cell(new Phrase(new Chunk("")));
                c1.addElement(brasao);
                c1.setBorderWidth(0);
                t.addCell(c1);
            }

            Cell c2 = new Cell(cabecalho);
            c2.setHorizontalAlignment(Cell.ALIGN_LEFT);
            c2.setBorderWidth(0);
            t.addCell(c2);

            p.clear();
            p.add(t);
            Chunk chunkTemp = new Chunk("_____________________________________________________________________________________________________", RelatorioPDF.TIMES_NORMAL_10);
            p.add(chunkTemp);

            p.clear();
            p.add(t);
            HeaderFooter header = new HeaderFooter(p, false);
            header.setBorder(Rectangle.NO_BORDER);          
            return header;
        } catch (Exception ex) {
            throw new ServletException("<red><br><br>Ocorreu um erro ao recuperar o cabe�alho do relat�rio.</red>");
        }
    }

    public HeaderFooter getConteudoRodape() throws ServletException {
        try {
            Phrase rodape = new Phrase();
            rodape.add(new Chunk("P�gina ", TIMES_NORMAL_10));
            HeaderFooter footer = new HeaderFooter(rodape, true);
            footer.setBorder(Rectangle.NO_BORDER);
            footer.setAlignment(Element.ALIGN_RIGHT);
            return footer;
        } catch (Exception ex) {
            throw new ServletException("<red><br><br>Ocorreu um erro ao gerar o rodap� do relat�rio.</red>");
        }
    }
}
