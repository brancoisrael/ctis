/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.guia.consulta.porSituacao;

import br.gov.tredf.tresaudeAdm.bean.Guia;
import br.gov.tredf.tresaudeAdm.bean.OrigemGuia;
import br.gov.tredf.tresaudeAdm.bean.Situacao;
import br.gov.tredf.tresaudeAdm.bean.TipoGuia;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;


/**
 * @author Camila Kinoshita
 */

public class Consulta extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher view = null;
        view = req.getRequestDispatcher("/restrita/user/guia/consulta/porSituacao/inicial.jsp");
        req.setAttribute("titulo", "Consulta de Guias por Situa��o");

        DataContext context = ServletUtil.getSessionContext(req.getSession());
        String codUsuario = req.getRemoteUser();
        if (codUsuario == null || codUsuario.equals("")) {
            throw new ServletException("C�digo do usu�rio est� com o valor nulo ou em branco.");
        }
        UsuarioAutorizado usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, codUsuario);
        req.setAttribute("usuarioAutorizado", usuarioAutorizado);

        OrigemGuia origemGuia = (OrigemGuia) DataObjectUtils.objectForPK(context, OrigemGuia.class, OrigemGuia.GUIAS_ON_LINE);
        req.setAttribute("origemGuia", origemGuia);

        SelectQuery query = new SelectQuery(Situacao.class);
        query.addOrdering(Situacao.NOM_SITUACAO_PROPERTY, true);
        List<Situacao> list = context.performQuery(query);
        req.setAttribute("listSituacao", list);

        String situacaoGuia = req.getParameter("codSituacao");

        if( situacaoGuia!=null && !situacaoGuia.trim().equals("")){
            int cod_situacao = Integer.parseInt(situacaoGuia);
            Object[] tipoGuiaValues = TipoGuia.getTiposDeGuia();
            Situacao situacao = (Situacao) DataObjectUtils.objectForPK(context, Situacao.class, cod_situacao);
            String nomSituacao = situacao.getNomSituacao();
            Integer codCredenciado = usuarioAutorizado.getToCredenciadoAutorizado().getCodCredenciado();
            Expression exp = null;
            exp = ExpressionFactory.matchExp(Guia.TO_SITUACAO_PROPERTY, situacao);
            exp = exp.andExp(ExpressionFactory.inExp(Guia.TO_TIPO_GUIA_PROPERTY, tipoGuiaValues));
            exp = exp.andExp(ExpressionFactory.matchExp(Guia.TO_ORIGEM_GUIA_PROPERTY, OrigemGuia.GUIAS_ON_LINE));
            exp = exp.andExp(ExpressionFactory.matchExp(Guia.TO_CREDENCIADO_PROPERTY, codCredenciado));
            SelectQuery select = new SelectQuery(Guia.class, exp);
            
            List<Guia> lista = context.performQuery(select);

            // orders a list aplying multiple orderings
            List orderings = new ArrayList();
            orderings.add(new Ordering(Guia.ANO_EXERCICIO_PROPERTY, false));
            orderings.add(new Ordering("numGuia", false));
            Ordering.orderList(lista, orderings);
            
            req.setAttribute("codSituacao", situacaoGuia);

            if(lista.size()>0){
                req.setAttribute("titulo", "Consulta de Guias por Situa��o - " + nomSituacao);
                req.setAttribute("listGuia", lista);
                req.setAttribute("titulo", "Guias recuperadas com sucesso");
            } else {
                req.setAttribute("erro", "Nenhuma guia encontrada.");
            }

        } else {
            req.setAttribute("erro", "Uma Situa��o deve ser selecionada.");
        }

        view.forward(req, resp);
    }

}