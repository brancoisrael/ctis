package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._CredenciadoAutorizado;

public class CredenciadoAutorizado extends _CredenciadoAutorizado {
    public Integer getCodCredenciado() {
        return (getObjectId() != null && !getObjectId().isTemporary())
            ? (Integer)getObjectId().getIdSnapshot().get(COD_CREDENCIADO_PK_COLUMN)
            : null;
    }
}
