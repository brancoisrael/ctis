package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._Situacao;

public class Situacao extends _Situacao {
    public static final int SITUACAO_CANCELADA = 1;
    public static final int SITUACAO_EM_ABERTO = 2;
    public static final int SITUACAO_EM_ANALISE = 3;
    public static final int SITUACAO_ANALISADA = 4;
    public static final int SITUACAO_PAGA = 5;
    public static final int SITUACAO_FATURADA = 6;
    public static final int SITUACAO_EM_AUTORIZACAO = 7;
    public static final int SITUACAO_AUTORIZADA = 8;
    public static final int SITUACAO_REJEITADA = 9;

    public Integer getCodSituacao() {
        return (getObjectId() != null && !getObjectId().isTemporary())
            ? (Integer)getObjectId().getIdSnapshot().get(COD_SITUACAO_PK_COLUMN)
            : null;
    }
}
