/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.guia.emissao;

import br.gov.tredf.tresaudeAdm.bean.Procedimento;
import br.gov.tredf.tresaudeAdm.bean.ProcedimentoAutorizado;
import br.gov.tredf.tresaudeAdm.bean.TipoGuia;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import br.gov.tredf.tresaudeAdm.utils.Debug;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;

/**
 *
 * @author igor
 */
public class GuiaEmissaoRecuperaProc extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        DecimalFormat decimalFormat = new DecimalFormat("###,##0.00");
        String codNomProcedimento = req.getParameter("codNomProcedimento");
        String tipoProcedimento = req.getParameter("tipoProcedimento");
        String matServidor = req.getParameter("matServidor");
        String codDepend = req.getParameter("codDependente");
        String codTipoGuia = req.getParameter("codTipoGuia");
        
        int tipoGuia = 0;
        
        if ((codTipoGuia != null) && (!codTipoGuia.equals(""))) {
            tipoGuia = Integer.parseInt(codTipoGuia);
        }

        if ((codNomProcedimento != null) && (!codNomProcedimento.equals(""))) {
            DataContext context = ServletUtil.getSessionContext(req.getSession());

            String codUsuario = req.getRemoteUser();
            UsuarioAutorizado usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, codUsuario);
            Integer codTabela = usuarioAutorizado.getToCredenciadoAutorizado().getToCredenciado().getToTabela().getCodTabela();

            Procedimento procedimento = null;
            List<Procedimento> listProcedimento;

            if (tipoProcedimento.trim().equals("PROCEDIMENTOS_AUTORIZADOS")) {
                // busca um procedimento autorizado por um c�digo exato
                procedimento = getProcedimentoAutorizado(context, codTabela, codNomProcedimento);
                if (procedimento == null) {
                    // busca procedimentos autorizados com nomes semelhantes ao texto digitado
                    listProcedimento = getProcedimentoAutorizadoArray(context, codTabela, codNomProcedimento);
                } else {
                    listProcedimento = new ArrayList<Procedimento>();
                    listProcedimento.add(procedimento);
                }
            } else { //tipoProcedimento.trim().equals("PROCEDIMENTOS_TODOS")
                // busca um procedimento por um c�digo exato
                procedimento = getProcedimento(context, codTabela, codNomProcedimento);
                if (procedimento == null) {
                    // busca procedimentos com nomes semelhantes ao texto digitado
                    listProcedimento = getProcedimentoArray(context, codTabela, codNomProcedimento);
                } else {
                    listProcedimento = new ArrayList<Procedimento>();
                    listProcedimento.add(procedimento);
                }
            }
            
            if(procedimento==null){
                procedimento = new Procedimento();
            }

            if(tipoGuia == TipoGuia.GUIA_MEDICA_CLINICA_LABORATORIAL){
                List listProcedimentosConsulta = procedimento.recuperarListaProcedimentosTipoConsulta(codTabela, context);
                boolean removeuProcedimentos = listProcedimento.removeAll(listProcedimentosConsulta);
            }
            
            if (listProcedimento != null && (!listProcedimento.isEmpty())) {
                String dados = "";
                int cont = 0;
                for (Procedimento procedimentoItem : listProcedimento) {
                    cont++;

                    dados += procedimentoItem.getCodProcedimento().toString();
                    dados += "\\#";
                    dados += procedimentoItem.getNomProcedimento();
                    dados += "\\#";
                    dados += decimalFormat.format(procedimentoItem.getValorProcedimento());
                    dados += "\\#";
                    dados += procedimentoItem.getRequerEspecialidade();
                    dados += "\\#";
                    dados += procedimento.getDataCarenciaProcedimentoPorPaciente(context, matServidor, codDepend, procedimentoItem.getCodProcedimento().toString(), codTabela);


                    if (cont < listProcedimento.size()) {
                        dados += "\\n";
                    }
                }
                    

                resp.setContentType("text/html");
                resp.getWriter().write(dados);
            } else {
                    String dados = "";
                    dados += "";
                    dados += "\\#";
                    dados += "";
                    dados += "\\#";
                    dados += "";
                    dados += "\\#";
                    dados += "";
                    dados += "\\#";
                    dados += "";
                resp.setContentType("text/html");
                resp.getWriter().write(dados);
            }
        }
    }

    private Procedimento getProcedimentoAutorizado(DataContext context, Integer codTabela, String codProcedimento) {
        Debug.debug(Debug.INICIO);
        System.out.println("\n\n\n SQL com procedimentos ATIVOS 1");
        Procedimento proc = null;        
        
        Map<String, Object> mapPk = new HashMap<String, Object>();
        mapPk.put(ProcedimentoAutorizado.COD_PROCEDIMENTO_PK_COLUMN, codProcedimento);
        mapPk.put(ProcedimentoAutorizado.COD_TABELA_PK_COLUMN, codTabela);
        ProcedimentoAutorizado procedimentoAutorizado = (ProcedimentoAutorizado) DataObjectUtils.objectForPK(context, ProcedimentoAutorizado.class, mapPk);
        if (procedimentoAutorizado == null) {
            proc = null;
        } else {

            proc = procedimentoAutorizado.getToProcedimento();
            if(!proc.getEhProcedimentoAtivo()){
                Debug.debug("PROCEDIMENTO INATIVO: " + proc.getCodNomProcedimento());
                proc = null;
            }
        }
        Debug.debug(Debug.FIM);
        return proc;
    }

    private List<Procedimento> getProcedimentoAutorizadoArray(DataContext context, Integer codTabela, String nomProcedimento) {
        Debug.debug(Debug.INICIO);        
        System.out.println("\n\n\n SQL com procedimentos ATIVOS 2");
        
        Expression expProcedimento = ExpressionFactory.matchDbExp(Procedimento.COD_TABELA_PK_COLUMN, codTabela);        
        expProcedimento = expProcedimento.andExp(ExpressionFactory.likeIgnoreCaseExp(Procedimento.NOM_PROCEDIMENTO_PROPERTY, "%" + nomProcedimento + "%"));
        expProcedimento = expProcedimento.andExp(ExpressionFactory.matchExp(Procedimento.PROCEDIMENTO_ATIVO_PROPERTY, 0));
        SelectQuery queryProcedimento = new SelectQuery(Procedimento.class, expProcedimento);
        queryProcedimento.addOrdering(Procedimento.NOM_PROCEDIMENTO_PROPERTY, true);
        List<Procedimento> lista = context.performQuery(queryProcedimento);
        
        Debug.debug(Debug.FIM);
        return lista;
    }

    private Procedimento getProcedimento(DataContext context, Integer codTabela, String codProcedimento) {
        Debug.debug(Debug.INICIO);
        System.out.println("\n\n\n SQL com procedimentos ATIVOS");
        Procedimento proc = null;
        Map<String, Object> mapPk = new HashMap<String, Object>();
        mapPk.put(Procedimento.COD_PROCEDIMENTO_PK_COLUMN, codProcedimento);
        mapPk.put(Procedimento.COD_TABELA_PK_COLUMN, codTabela);
        Procedimento procedimento = (Procedimento) DataObjectUtils.objectForPK(context, Procedimento.class, mapPk);
        if(procedimento!= null && procedimento.getEhProcedimentoAtivo()){
            proc = procedimento;
        } else {
            Debug.debug("PROCEDIMENTO INATIVO: " + procedimento.getCodNomProcedimento());
        }
        Debug.debug(Debug.FIM);
        return proc;
    }

    private List<Procedimento> getProcedimentoArray(DataContext context, Integer codTabela, String nomProcedimento) {
        Debug.debug(Debug.INICIO);
        System.out.println("\n\n\n SQL com procedimentos ATIVOS");
        Expression expProcedimento = ExpressionFactory.matchDbExp(Procedimento.COD_TABELA_PK_COLUMN, codTabela);
        expProcedimento = expProcedimento.andExp(ExpressionFactory.likeIgnoreCaseExp(Procedimento.NOM_PROCEDIMENTO_PROPERTY, "%" + nomProcedimento + "%"));
        expProcedimento = expProcedimento.andExp(ExpressionFactory.matchExp(Procedimento.PROCEDIMENTO_ATIVO_PROPERTY, 0));
        SelectQuery queryProcedimento = new SelectQuery(Procedimento.class, expProcedimento);
        queryProcedimento.addOrdering(Procedimento.NOM_PROCEDIMENTO_PROPERTY, true);
        List<Procedimento> lista = context.performQuery(queryProcedimento);
        Debug.debug(Debug.FIM);
        return lista;
    }
    
}
