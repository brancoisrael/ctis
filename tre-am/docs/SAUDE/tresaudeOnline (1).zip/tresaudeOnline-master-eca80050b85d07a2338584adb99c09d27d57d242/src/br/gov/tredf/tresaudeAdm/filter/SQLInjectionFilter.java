/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.filter;

import java.io.IOException;
import java.rmi.ServerException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 *
 * @author 
 */
public class SQLInjectionFilter implements Filter {

    @Override
    public void init(FilterConfig fc) throws ServletException {
        
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
        for (Object paramName : req.getParameterMap().keySet()) {
            String[] params = (String[]) req.getParameterMap().get(paramName);
            
            for (String param : params) {
                if(param.indexOf("'")>=0
                        || param.indexOf("--")>=0
                        || param.indexOf(";")>=0){
                    throw  new ServerException("SQL Injection");
                }
            }
            
        }
        
        chain.doFilter(req, resp);
    }

    @Override
    public void destroy() {
        
    }
    
}
