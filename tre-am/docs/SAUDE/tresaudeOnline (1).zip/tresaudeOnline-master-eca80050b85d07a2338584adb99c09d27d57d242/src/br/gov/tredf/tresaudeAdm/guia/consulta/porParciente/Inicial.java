/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.guia.consulta.porParciente;

import br.gov.tredf.tresaudeAdm.bean.OrigemGuia;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;


/**
 * @author camilak
 */
public class Inicial  extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String titulo = "Consulta de Guias por Paciente";
        req.setAttribute("titulo", titulo);

        String codUsuario = req.getRemoteUser();

        if (codUsuario == null || codUsuario.equals("")) {
            throw new ServletException("C�digo do usu�rio est� com o valor nulo ou em branco.");
        }

        DataContext context = ServletUtil.getSessionContext(req.getSession());

        UsuarioAutorizado usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, codUsuario);
        req.setAttribute("usuarioAutorizado", usuarioAutorizado);

        OrigemGuia origemGuia = (OrigemGuia) DataObjectUtils.objectForPK(context, OrigemGuia.class, OrigemGuia.GUIAS_ON_LINE);
        req.setAttribute("origemGuia", origemGuia);

        RequestDispatcher view = req.getRequestDispatcher("/restrita/user/guia/consulta/porPaciente/inicial.jsp");
        view.forward(req, resp);
    }

}