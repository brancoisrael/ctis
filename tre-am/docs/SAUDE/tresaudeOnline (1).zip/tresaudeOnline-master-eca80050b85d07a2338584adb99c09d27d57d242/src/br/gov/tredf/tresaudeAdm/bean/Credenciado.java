package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._Credenciado;
import java.util.Calendar;

public class Credenciado extends _Credenciado {
    public String getDatValidadeContratoS() {
        if (getDatValidadeContrato() != null) {
            Calendar validade = Calendar.getInstance();
            validade.setTime(getDatValidadeContrato());
            Integer dia = validade.get(Calendar.DAY_OF_MONTH);
            Integer mes = validade.get(Calendar.MONTH) + 1;
            Integer ano = validade.get(Calendar.YEAR);
            return dia.toString() + "/" + mes.toString() + "/" + ano.toString();
        } else {
            return null;
        }
    }
}
