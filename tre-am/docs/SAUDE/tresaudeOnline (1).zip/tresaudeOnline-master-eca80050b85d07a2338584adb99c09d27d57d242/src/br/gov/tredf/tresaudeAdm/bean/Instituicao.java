package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._Instituicao;

public class Instituicao extends _Instituicao {

}
