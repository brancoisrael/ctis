/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm;

import com.lowagie.text.BadElementException;
import com.lowagie.text.Cell;
import com.lowagie.text.Chunk;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.Image;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.Table;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author camilak
 */
public abstract class RelatorioPDF extends HttpServlet {

    public static final Font TIMES_BOLD_12_UNDERLINE = FontFactory.getFont(FontFactory.TIMES_BOLD, 12, Font.UNDERLINE);
    public static final Font TIMES_BOLD_12 = FontFactory.getFont(FontFactory.TIMES_BOLD, 12, Font.BOLD);
    public static final Font TIMES_NORMAL_12 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.NORMAL);
    public static final Font TIMES_BOLD_11_UNDERLINE = FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Font.UNDERLINE);
    public static final Font TIMES_BOLD_11 = FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Font.BOLD);
    public static final Font TIMES_NORMAL_11 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 11, Font.NORMAL);
    public static final Font TIMES_BOLD_10_UNDERLINE = FontFactory.getFont(FontFactory.TIMES_BOLD, 10, Font.UNDERLINE);
    public static final Font TIMES_BOLD_10 = FontFactory.getFont(FontFactory.TIMES_BOLD, 10, Font.BOLD);
    public static final Font TIMES_NORMAL_10 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Font.NORMAL);
    public static final Font TIMES_BOLD_9_UNDERLINE = FontFactory.getFont(FontFactory.TIMES_BOLD, 9, Font.UNDERLINE);
    public static final Font TIMES_BOLD_9 = FontFactory.getFont(FontFactory.TIMES_BOLD, 9, Font.BOLD);
    public static final Font TIMES_NORMAL_9 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 9, Font.NORMAL);
    public static final Font TIMES_BOLD_18_UNDERLINE = FontFactory.getFont(FontFactory.TIMES_BOLD, 18, Font.UNDERLINE);
    public static final Font TIMES_BOLD_18 = FontFactory.getFont(FontFactory.TIMES_BOLD, 18, Font.BOLD);
    public static final Font TIMES_NORMAL_18 = FontFactory.getFont(FontFactory.TIMES_BOLD, 18, Font.NORMAL);
    static public String IMAGEM_BRASAO = "http://adm.justicaeleitoral.jus.br/imagens/imagens/tre-df-imagem-brasao-armas/image_large/image?ext=.jpg";
    static public String IMAGEM_CARIMBO = "http://adm.justicaeleitoral.jus.br/imagens/imagens/tre-df-imagem-carimbo-folha/image_large/image?ext=.jpg";
    static Image imagem = null;
    static Image imagemCarimbo = null;
    protected Image assinatura = null;
    public static int RECUO = 250;
    protected String titulo = null;
    protected Font fonteTitulo = TIMES_BOLD_12_UNDERLINE;
    protected String contentType = "application/pdf";  // pode ser "application/msword"

    public void setTitulo(String pTitulo) {
        titulo = pTitulo;
    }

    public void setTitulo(String pTitulo, Font pFonte) {
        titulo = pTitulo;
        fonteTitulo = pFonte;
    }

    public void setContentType(String pContent) {
        contentType = pContent;
    }

    //Initialize global variables
    public void init() throws ServletException {
    }

    public static Phrase getCabecalho() throws DocumentException {
        Phrase p = new Phrase();
        try {
            Phrase cabecalho = new Phrase();
            cabecalho.add(new Chunk("\nTRIBUNAL REGIONAL ELEITORAL - DF\n", TIMES_BOLD_12));
            cabecalho.add(new Chunk("TRE-Sa�de\n", TIMES_BOLD_12));
            cabecalho.add(new Chunk("Guia M�dica", TIMES_BOLD_12));

            Table t = null;
            t = new Table(3, 1);//3 colunas e 1 linha
            t.setWidth(100);
            t.setWidths(new int[]{20,60,20}); //largura das coluna
            t.setBorderWidth(0);
            //Linha1: c1, c3 e c2

            Image brasao = getImagemBrasao();
            if (brasao != null) {
                brasao.scalePercent(70);
                brasao.setAlignment(Image.ALIGN_CENTER);
                Cell c1 = new Cell(new Phrase(new Chunk("")));
                c1.addElement(brasao);
                c1.setBorderWidth(0);
                t.addCell(c1);
            }

            Cell c3 = new Cell(cabecalho);
            c3.setHorizontalAlignment(Cell.ALIGN_LEFT);
            c3.setBorderWidth(0);
            t.addCell(c3);

            Image carimbo = getImagemCarimbo();
            if (carimbo != null) {
                carimbo.scalePercent(70);
                carimbo.setAlignment(Image.ALIGN_RIGHT);
                Cell c2 = new Cell(new Phrase(new Chunk("")));
                c2.addElement(carimbo);
                c2.setBorderWidth(0);
                t.addCell(c2);
            }

            p.clear();
            p.add(t);
            Chunk chunkTemp = new Chunk("_____________________________________________________________________________________________________", RelatorioPDF.TIMES_NORMAL_10);
            p.add(chunkTemp);

        } catch (BadElementException ex) {
            Logger.getLogger(RelatorioPDF.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;
    }

    public static HeaderFooter getHeader() throws Exception {
            //Adicionando o cabe�alho (P�ginas seguintes)
            HeaderFooter header = new HeaderFooter(getCabecalho(), false);
            header.setBorder(Rectangle.NO_BORDER);
            return header;
    }

    public static Image getImagemBrasao() {
        try {
            imagem = Image.getInstance(IMAGEM_BRASAO);
            imagem.scalePercent(70);
            imagem.setAlignment(Image.ALIGN_CENTER);
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return imagem;
    }

    public static Image getImagemCarimbo() {
        try {
            imagemCarimbo = Image.getInstance(IMAGEM_CARIMBO);
            imagemCarimbo.scalePercent(70);
            imagemCarimbo.setAlignment(Image.ALIGN_RIGHT);
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return imagemCarimbo;
    }

    public Paragraph getTitulo() {
        Paragraph pTitulo = new Paragraph(titulo, fonteTitulo);
        pTitulo.setAlignment(Element.ALIGN_CENTER);
        return pTitulo;
    }

    public Paragraph getRodape() throws BadElementException, Exception {
        Paragraph rodape = null;

        return rodape;
    }
   /**
    * processa HttpServlet request
    */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ByteArrayOutputStream baos=new ByteArrayOutputStream();
        try {
            if (imprime(request, response, baos)) {
                response.setContentType("application/pdf");
                //Passando para a saida o tamanho do conte�do a ser enviado.
                response.setContentLength(baos.size());
                //Passando o pdf para a sa�da.
                response.getOutputStream().write(baos.toByteArray());
                response.getOutputStream().flush();
                response.getOutputStream().close();
            }
        } catch (ServletException se) {
            throw se;
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //throw new ServletException("Falta implementar a Servlet de ImprimirDetalhamento das avalia��es");
        try {
            doGet(req,resp);
        } catch (ServletException s){
            throw s;
        } catch (IOException i){
            throw i;
        }
        //throw new ServletException("N�o � poss�vel imprimir");
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            doGet(req,resp);
        } catch (ServletException s){
            throw s;
        } catch (IOException i){
            throw i;
        }
    }
    
   /**
    * M�todo utilizado para montar o relat�rio para impress�o.
    * @param pBaos ByteArrayOutputStream
    * @param pParametros Parametro
    */
    public abstract boolean imprime(HttpServletRequest request, HttpServletResponse response, ByteArrayOutputStream pBaos) throws DocumentException, BadElementException, Exception;

   
}
