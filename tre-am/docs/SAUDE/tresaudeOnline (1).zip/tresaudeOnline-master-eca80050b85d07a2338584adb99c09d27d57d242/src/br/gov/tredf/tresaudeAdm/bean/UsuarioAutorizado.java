package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._UsuarioAutorizado;


public class UsuarioAutorizado extends _UsuarioAutorizado {
    public final String SENHA_PADRAO = "!){`^}:?";

    public String getSenha() {
        return SENHA_PADRAO;
    }

    public String getSenhaConfirma() {
        return SENHA_PADRAO;
    }

    public String getBloqueadoS() {
        if (getBloqueado() != null) {
            if (getBloqueado()) {
                return "SIM";
            } else {
                return "N�O";
            }

        } else {
            return "";
        }
    }
    
}
