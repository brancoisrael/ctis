/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.guiaDeConsulta.emissao;

import br.gov.tredf.tresaudeAdm.bean.Procedimento;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;

/**
 *
 * @author camilak
 */
public class VerificarCarenciaConsulta extends HttpServlet {

     @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String matServidor = req.getParameter("matServidor");
        String codDependente = req.getParameter("codDependente");
        String codProcedimentoConsulta = req.getParameter("codProcedimentoConsulta");
        String codTabela = req.getParameter("codTabela");
        int cod_tabela = Integer.parseInt(codTabela);

        if ((matServidor != null) && (!matServidor.equals("")) && (codProcedimentoConsulta != null) && (!codProcedimentoConsulta.equals("")) && (codDependente != null) && (!codDependente.equals(""))) {
            try {

                DataContext context = ServletUtil.getSessionContext(req.getSession());
                Procedimento procedimento = new Procedimento();
                String dados = procedimento.getDataCarenciaProcedimentoPorPaciente(context, matServidor, codDependente, codProcedimentoConsulta, cod_tabela);

                resp.setContentType("text/html");
                resp.getWriter().write(dados);
            } catch (Exception e) {
                resp.setContentType("text/html");
                resp.getWriter().write("");
            }
        }
    }
}
