package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._SituacaoFuncional;

public class SituacaoFuncional extends _SituacaoFuncional {

}
