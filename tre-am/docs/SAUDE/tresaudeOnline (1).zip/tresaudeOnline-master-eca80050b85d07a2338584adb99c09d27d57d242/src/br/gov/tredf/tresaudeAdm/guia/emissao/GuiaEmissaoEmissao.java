/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.guia.emissao;

import br.gov.tredf.tresaudeAdm.bean.Beneficiario;
import br.gov.tredf.tresaudeAdm.bean.Guia;
import br.gov.tredf.tresaudeAdm.bean.GuiaProcedimento;
import br.gov.tredf.tresaudeAdm.bean.OrigemGuia;
import br.gov.tredf.tresaudeAdm.bean.Procedimento;
import br.gov.tredf.tresaudeAdm.bean.ProcedimentoAutorizado;
import br.gov.tredf.tresaudeAdm.bean.Situacao;
import br.gov.tredf.tresaudeAdm.bean.TipoGuia;
import br.gov.tredf.tresaudeAdm.bean.Usuario;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.DataRow;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SQLTemplate;
import org.apache.cayenne.query.SelectQuery;

/**
 *
 * @author igor
 */
public class GuiaEmissaoEmissao extends HttpServlet {

     @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        int situacaoGuia = -1;
        if(req.getParameter("situacaoGuia")!=null){
            if(req.getParameter("situacaoGuia").trim().equals("EM_AUTORIZACAO")){
                situacaoGuia = Situacao.SITUACAO_EM_AUTORIZACAO;
            }
            if(req.getParameter("situacaoGuia").trim().equals("EM_ABERTO")){
                situacaoGuia = Situacao.SITUACAO_EM_ABERTO;
            }
        }else{
            throw new ServletException("Situa��o da Guia n�o pode ser recuperada. Por favor tente novamente.");
        }

        String matServidor = req.getParameter("matServidor");

        if (matServidor == null || matServidor.equals("")) {
            throw new ServletException("Matr�cula do Servidor � campo obrigat�rio");
        }

        String strCodDepend = req.getParameter("codDepend");
        Integer codDepend = null;

        if (strCodDepend == null || strCodDepend.equals("")) {
            throw new ServletException("Paciente � campo obrigat�rio");
        } else {
            if (!strCodDepend.equals("0")) {
                codDepend = new Integer(strCodDepend);
            }
        }

        DataContext context = ServletUtil.getSessionContext(req.getSession());

        Expression expBeneficiario = ExpressionFactory.matchDbExp(Beneficiario.MAT_SERVIDOR_PK_COLUMN, matServidor);
        expBeneficiario = expBeneficiario.andExp(ExpressionFactory.matchExp(Beneficiario.COD_DEPEND_PROPERTY, codDepend));
        SelectQuery queryBeneficiario = new SelectQuery(Beneficiario.class, expBeneficiario);
        List<Beneficiario> listBeneficiario = context.performQuery(queryBeneficiario);
        Beneficiario beneficiario = null;

        if (listBeneficiario.size() != 1) {
            throw new ServletException("Benefici�rio inv�lido");
        } else {
            beneficiario = listBeneficiario.get(0);
        }

        if (beneficiario.getExcluido().equals("S")) {
            throw new ServletException("Benefici�rio exclu�do do plano");
        }

//  Comentado por camila em 03/09/2014
//  A carencia eh diferente para cada procedimento
//        if (beneficiario.getCarencia().equals("S")) {
//            throw new ServletException("Benefici�rio em per�odo de car�ncia");
//        }

        if (beneficiario.getSuspenso().equals("S")) {
            throw new ServletException("Benefici�rio suspenso temporariamente");
        }

        String guiaProcedimento[] = req.getParameterValues("guiaProcedimento");

        if (guiaProcedimento == null) {
            throw new ServletException("Pelo menos um procedimento deve ser selecionado");
        }

        String codUsuario = req.getRemoteUser();
        UsuarioAutorizado usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, codUsuario);
        
        Integer cod_tabela = usuarioAutorizado.getToCredenciadoAutorizado().getToCredenciado().getToTabela().getCodTabela();
        TipoGuia tipoGuia = (TipoGuia) DataObjectUtils.objectForPK(context, TipoGuia.class, TipoGuia.GUIA_MEDICA_CLINICA_LABORATORIAL);
        OrigemGuia origemGuia = (OrigemGuia) DataObjectUtils.objectForPK(context, OrigemGuia.class, OrigemGuia.GUIAS_ON_LINE);
                            
        Calendar calEmissao = Calendar.getInstance();
        calEmissao.set(Calendar.HOUR_OF_DAY, 0);
        calEmissao.set(Calendar.MINUTE, 0);
        calEmissao.set(Calendar.SECOND, 0);
        Date datEmissao = calEmissao.getTime();
        
        String dat = datEmissao.toString();
        System.out.println("DATA: "+dat);
        
        Map<String, Object> mapPkGuia = new HashMap<String, Object>();
        mapPkGuia.put(Guia.ANO_EXERCICIO_PK_COLUMN, Calendar.YEAR);
        mapPkGuia.put(Guia.COD_TIP_GUIA_PK_COLUMN, tipoGuia.getCodTipGuia());
        Guia guia_ = (Guia) DataObjectUtils.objectForPK(context, Guia.class, mapPkGuia); 
        
        SQLTemplate sqlTempGuia = new SQLTemplate(Guia.class, "select max(num_guia) num_guia from guia");
        sqlTempGuia.setFetchingDataRows(true);                
        List<DataRow> listRowTempGuia = context.performQuery(sqlTempGuia);
        Integer numGuia = (Integer) listRowTempGuia.get(0).get("NUM_GUIA");                        
                
        if(guia_==null){                    
            numGuia++;
        }        
        
        Guia guia = (Guia) context.newObject(Guia.class);
        try {
            guia.setToEspecialidade(null);
            guia.setNumGuia(numGuia);
            guia.setMatServidor(beneficiario.getMatServidor());
            guia.setCodDepend(beneficiario.getCodDepend());
            guia.setDatEmissao(datEmissao);
            guia.setToCredenciado(usuarioAutorizado.getToCredenciadoAutorizado().getToCredenciado());
            guia.setToTipoGuia(tipoGuia);
            guia.setFuncao(beneficiario.getToTitular().getFuncao());
            guia.setCusteio(tipoGuia.getCusteio());
            guia.setToSituacaoFuncional(beneficiario.getToTitular().getToSituacaoFuncional());
            guia.setToOrigemGuia(origemGuia);
            guia.setIndPagAtend(false);
            guia.setIndDespesaHospitalar(false);
            guia.setIndApartamento(false);
            guia.setIndUrgencia(false);
            guia.setIndInternacao(false);
            guia.setAnoExercicio(guia.getAnoVigente(context));
            guia.setTotal(0.0);
            
            Procedimento proc = new Procedimento();
            List<Procedimento> listaConsultas = proc.recuperarListaProcedimentosTipoConsulta(cod_tabela, context);

            boolean soProcedimentosAutorizados = true;
            for (int i = 0; i < guiaProcedimento.length; i++) {
                Procedimento procedimento = null;
                ProcedimentoAutorizado procedimentoAutorizado = null;

                String linha[] = guiaProcedimento[i].split("\\\\#");
                String codProcedimento = linha[0];
                String nomProcedimento = linha[1];
//                String valor = linha[2];
//                String req_especialidade = linha[3];
                String carencia = linha[4];
                String strQtde = linha[5];
                Integer qtde = null;

                try {
                    qtde = new Integer(strQtde);
                } catch (Exception e) {
                    throw new ServletException("N�o foi poss�vel converter a quantidade " + strQtde + " para inteiro");
                }
                
                for(Procedimento procedimentoConsulta: listaConsultas){
                    if(codProcedimento.equals(procedimentoConsulta.getCodProcedimento())){
                        throw new ServletException("N�o � permitido incluir o procedimento " + procedimentoConsulta.getCodNomProcedimento() + " em uma guia Clinica/Laboratorial.");
                    }
                }
                
                if( ! "sem car�ncia".equals(carencia)){
                    throw new ServletException("Este paciente possui car�ncia at� " + carencia + " para realizar o procedimento " +codProcedimento + " - " + nomProcedimento + ".");
                }

                if(situacaoGuia == Situacao.SITUACAO_EM_ABERTO){
                    Map<String, Object> mapPkProcedimetoAutorizado = new HashMap<String, Object>();
                    mapPkProcedimetoAutorizado.put(ProcedimentoAutorizado.COD_PROCEDIMENTO_PK_COLUMN, codProcedimento);
                    mapPkProcedimetoAutorizado.put(ProcedimentoAutorizado.COD_TABELA_PK_COLUMN, cod_tabela);
                    procedimentoAutorizado = (ProcedimentoAutorizado) DataObjectUtils.objectForPK(context, ProcedimentoAutorizado.class, mapPkProcedimetoAutorizado);

                    if (procedimentoAutorizado == null) {
                        throw new ServletException("O procedimento " + codProcedimento + " (" + nomProcedimento + ") n�o est� autorizado");
                    }

                    Map<String, Object> mapPkProcedimento = new HashMap<String, Object>();
                    mapPkProcedimento.put(ProcedimentoAutorizado.COD_PROCEDIMENTO_PK_COLUMN, codProcedimento);
                    mapPkProcedimento.put(ProcedimentoAutorizado.COD_TABELA_PK_COLUMN, cod_tabela);
                    procedimento = (Procedimento) DataObjectUtils.objectForPK(context, Procedimento.class, mapPkProcedimento);

                    if (procedimento == null) {
                        throw new ServletException("O procedimento " + codProcedimento + " (" + nomProcedimento + ") n�o est� dispon�vel");
                    }
                }

                if(situacaoGuia == Situacao.SITUACAO_EM_AUTORIZACAO){
                    Map<String, Object> mapPkProcedimetoAutorizado = new HashMap<String, Object>();
                    mapPkProcedimetoAutorizado.put(ProcedimentoAutorizado.COD_PROCEDIMENTO_PK_COLUMN, codProcedimento);
                    mapPkProcedimetoAutorizado.put(ProcedimentoAutorizado.COD_TABELA_PK_COLUMN, cod_tabela);
                    procedimentoAutorizado = (ProcedimentoAutorizado) DataObjectUtils.objectForPK(context, ProcedimentoAutorizado.class, mapPkProcedimetoAutorizado);

                    if (procedimentoAutorizado == null) {
                        soProcedimentosAutorizados = false;
                    }

                    Map<String, Object> mapPkProcedimeto = new HashMap<String, Object>();
                    mapPkProcedimeto.put(Procedimento.COD_PROCEDIMENTO_PK_COLUMN, codProcedimento);
                    mapPkProcedimeto.put(Procedimento.COD_TABELA_PK_COLUMN, cod_tabela);
                    procedimento = (Procedimento) DataObjectUtils.objectForPK(context, Procedimento.class, mapPkProcedimeto);

                    if (procedimento == null) {
                        throw new ServletException("O procedimento " + codProcedimento + " (" + nomProcedimento + ") n�o est� dispon�vel");
                    }
                }

                GuiaProcedimento guiaProcedimentoObj = (GuiaProcedimento) context.newObject(GuiaProcedimento.class);
                
                guiaProcedimentoObj.setToGuia(guia);
                guiaProcedimentoObj.setToProcedimento(procedimento);
                guiaProcedimentoObj.setAnoExercicio(guia.getAnoExercicio());
                guiaProcedimentoObj.setCodTipGuia(guia.getToTipoGuia().getCodTipGuia());
                guiaProcedimentoObj.setCodProcedimento(procedimento.getCodProcedimento());
                guiaProcedimentoObj.setQtde(qtde);
                guiaProcedimentoObj.setValor(procedimento.getValorProcedimento());
                guiaProcedimentoObj.setValorcalc(guiaProcedimentoObj.getQtde() * guiaProcedimentoObj.getValor());
                guiaProcedimentoObj.setVideo(false);
                guiaProcedimentoObj.setViaAcesso(false);
                guia.setTotal(guia.getTotal() + guiaProcedimentoObj.getValorcalc());
            }

            if(soProcedimentosAutorizados){
                // se era pra ser em_autoriza��o, mas tem apenas procedimentos autorizados
                if(situacaoGuia == Situacao.SITUACAO_EM_AUTORIZACAO){
                    guia.setToUsuarioAutorizadoSolicita(usuarioAutorizado);
                    guia.setDataSolicitacaoWeb(datEmissao);
                    guia.setDataAutorizacaoTre(datEmissao);
                    guia.setToUsuarioAutorizacaoTRE(null);
                    guia.setJustificativa("Esta guia contem apenas procedimentos autorizados.");
                }
                situacaoGuia = Situacao.SITUACAO_EM_ABERTO;
                guia.setToUsuarioAutorizado(usuarioAutorizado);
                guia.setToSituacao((Situacao) DataObjectUtils.objectForPK(context, Situacao.class, situacaoGuia));
            }else{
                situacaoGuia = Situacao.SITUACAO_EM_AUTORIZACAO;
                guia.setToUsuarioAutorizadoSolicita(usuarioAutorizado);
                guia.setDataSolicitacaoWeb(datEmissao);
                guia.setToSituacao((Situacao) DataObjectUtils.objectForPK(context, Situacao.class, situacaoGuia));
            }

            context.commitChanges();
        } catch (Exception e) {
            context.rollbackChanges();
            throw new ServletException(e);
        }

        req.setAttribute("guia", guia);
        
        RequestDispatcher view = req.getRequestDispatcher("/restrita/user/guia/emissao/sucesso.jsp");
        view.forward(req, resp);
        
    }
}
