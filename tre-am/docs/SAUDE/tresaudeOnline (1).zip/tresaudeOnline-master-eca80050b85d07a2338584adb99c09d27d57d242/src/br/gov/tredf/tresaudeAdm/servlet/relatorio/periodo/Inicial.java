

package br.gov.tredf.tresaudeAdm.servlet.relatorio.periodo;


import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author Eneias
 */
public class Inicial extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String titulo = "Relat�rio por per�odo";
        String codCredenciado = req.getRemoteUser();
        
        if (codCredenciado == null || codCredenciado.equals("")) {
            throw new ServletException("C�digo do usu�rio est� com o valor nulo ou em branco.");
        }
        req.setAttribute("titulo", titulo);
        req.setAttribute("codCredenciado", codCredenciado);
        RequestDispatcher view = req.getRequestDispatcher("/restrita/adm/relatorio/periodo/relatorioPorPeriodo.jsp");
        view.forward(req, resp);
    }


}
