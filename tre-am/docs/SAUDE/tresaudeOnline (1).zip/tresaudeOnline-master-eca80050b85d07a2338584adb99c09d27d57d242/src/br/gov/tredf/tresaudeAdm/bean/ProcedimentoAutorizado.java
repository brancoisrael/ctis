package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._ProcedimentoAutorizado;
import static br.gov.tredf.tresaudeAdm.bean.auto._ProcedimentoAutorizado.COD_PROCEDIMENTO_PK_COLUMN;
import java.util.HashMap;
import java.util.Map;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;

public class ProcedimentoAutorizado extends _ProcedimentoAutorizado {
    
    public String getCodProcedimento() {
         
       return (getObjectId() != null && !getObjectId().isTemporary())
                ? (String) getObjectId().getIdSnapshot().get(COD_PROCEDIMENTO_PK_COLUMN)
                : null;          
    }
     
    public Integer getTabela() {         
       return (getObjectId() != null && !getObjectId().isTemporary())
                ? (Integer) getObjectId().getIdSnapshot().get(COD_TABELA_PK_COLUMN)
                : null;
    }
    
    public Procedimento getToProcedimento(){
        DataContext context = this.getDataContext();         
        Map<String, Object> mapPk = new HashMap<String, Object>();
        mapPk.put(Procedimento.COD_TABELA_PK_COLUMN, this.getTabela());
        mapPk.put(Procedimento.COD_PROCEDIMENTO_PK_COLUMN, this.getCodProcedimento());
        return (Procedimento) DataObjectUtils.objectForPK(context, Procedimento.class, mapPk);              
                
    }
}
