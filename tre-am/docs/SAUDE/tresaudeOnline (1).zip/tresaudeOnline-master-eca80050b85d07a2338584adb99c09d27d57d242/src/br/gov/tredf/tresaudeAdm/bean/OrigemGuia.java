package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._OrigemGuia;

public class OrigemGuia extends _OrigemGuia {
    public static final int GUIAS_ON_LINE = 3;
}
