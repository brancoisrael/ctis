/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.gov.tredf.tresaudeAdm.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 *
 * @author igor
 */
public class CriptoMD5 {
    public static String cripto(String value) throws NoSuchAlgorithmException {
        String auxReturn = "";
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] hashByte = md.digest((value).getBytes());
        char[] hashChar = hexCodes(hashByte);
        for (char charSenha: hashChar) {
            auxReturn = auxReturn + charSenha;
        }
        return auxReturn.toUpperCase();
    }

    private static char[] hexCodes(byte[] text) {
        char[] hexOutput = new char[text.length * 2];
        String hexString;
        for (int i = 0; i < text.length; i++) {
            hexString = "00" + Integer.toHexString(text[i]);
            hexString.getChars(hexString.length() - 2,
                                    hexString.length(), hexOutput, i * 2);
        }
        return hexOutput;
    }
}
