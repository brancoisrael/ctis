/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.guiaMedicamento.emissao;

import br.gov.tredf.tresaudeAdm.bean.Beneficiario;
import br.gov.tredf.tresaudeAdm.bean.Guia;
import br.gov.tredf.tresaudeAdm.bean.OrigemGuia;
import br.gov.tredf.tresaudeAdm.bean.Procedimento;
import br.gov.tredf.tresaudeAdm.bean.Situacao;
import br.gov.tredf.tresaudeAdm.bean.TipoGuia;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import br.gov.tredf.tresaudeAdm.utils.Util;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.DataRow;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SQLTemplate;
import org.apache.cayenne.query.SelectQuery;

/**
 * @author Camila Kinoshita
 */
public class Emissao extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String titulo = "Guia emitida com sucesso";
        req.setAttribute("titulo", titulo);

        String matServidor = req.getParameter("matServidor");
        if (matServidor == null || matServidor.equals("")) {
            throw new ServletException("Matr�cula do Servidor � campo obrigat�rio");
        }

        String strCodDepend = req.getParameter("codDepend");
        Integer codDepend = null;
        if (strCodDepend == null || strCodDepend.equals("")) {
            throw new ServletException("Paciente � campo obrigat�rio");
        } else {
            if (!strCodDepend.equals("0")) {
                codDepend = new Integer(strCodDepend);
            }
        }

        String descricao = req.getParameter("descricao");

        int indApartamento = -1;
        if (req.getParameter("indApartamento") != null) {
            indApartamento = Integer.parseInt(req.getParameter("indApartamento"));
        }

        int indInternacao = -1;
        if (req.getParameter("indInternacao") != null) {
            indInternacao = Integer.parseInt(req.getParameter("indInternacao"));
        }

        DataContext context = ServletUtil.getSessionContext(req.getSession());

        Expression expBeneficiario = ExpressionFactory.matchDbExp(Beneficiario.MAT_SERVIDOR_PK_COLUMN, matServidor);
        expBeneficiario = expBeneficiario.andExp(ExpressionFactory.matchExp(Beneficiario.COD_DEPEND_PROPERTY, codDepend));
        SelectQuery queryBeneficiario = new SelectQuery(Beneficiario.class, expBeneficiario);
        List<Beneficiario> listBeneficiario = context.performQuery(queryBeneficiario);
        Beneficiario beneficiario = null;

        if (listBeneficiario.size() != 1) {
            throw new ServletException("Benefici�rio inv�lido");
        } else {
            beneficiario = listBeneficiario.get(0);
        }

        if (beneficiario.getExcluido().equals("S")) {
            throw new ServletException("Benefici�rio exclu�do do plano");
        }

        if (beneficiario.getSuspenso().equals("S")) {
            throw new ServletException("Benefici�rio suspenso temporariamente");
        }

        String codUsuario = req.getRemoteUser();
        UsuarioAutorizado usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, codUsuario);
        Integer cod_tabela = usuarioAutorizado.getToCredenciadoAutorizado().getToCredenciado().getToTabela().getCodTabela();

        Procedimento procedimentoConsulta = new Procedimento();
        procedimentoConsulta = procedimentoConsulta.recuperarProcedimentoConsulta(context, usuarioAutorizado);

        String carencia = procedimentoConsulta.getDataCarenciaProcedimentoPorPaciente(context, matServidor, strCodDepend, procedimentoConsulta.getCodProcedimento(), cod_tabela);
        boolean temCarencia = false;
        if (!"sem car�ncia".equals(carencia)) {
            temCarencia = true;
//            throw new ServletException("Este paciente possui car�ncia at� " + carencia + " para realizar o procedimento " + procedimentoConsulta.getCodNomProcedimento() + ".");
        }

        TipoGuia tipoGuia = (TipoGuia) DataObjectUtils.objectForPK(context, TipoGuia.class, TipoGuia.GUIA_MEDICA_CIRURGICA_HOSPITALAR);

        OrigemGuia origemGuia = (OrigemGuia) DataObjectUtils.objectForPK(context, OrigemGuia.class, OrigemGuia.GUIAS_ON_LINE);

        Calendar calEmissao = Calendar.getInstance();
        calEmissao.set(Calendar.HOUR_OF_DAY, 0);
        calEmissao.set(Calendar.MINUTE, 0);
        calEmissao.set(Calendar.SECOND, 0);
        calEmissao.set(Calendar.MILLISECOND, 0);
        Date datEmissao = calEmissao.getTime();
        
        String ano = datEmissao.toString().substring(24, datEmissao.toString().length());
        Map<String, Object> mapPkGuia = new HashMap<String, Object>();
        mapPkGuia.put(Guia.ANO_EXERCICIO_PK_COLUMN, ano);
        mapPkGuia.put(Guia.COD_TIP_GUIA_PK_COLUMN, tipoGuia.getCodTipGuia());      
        mapPkGuia.put(Guia.TO_CREDENCIADO_PROPERTY,usuarioAutorizado.getToCredenciadoAutorizado().getToCredenciado() );
        Guia guia_ = (Guia) DataObjectUtils.objectForPK(context, Guia.class, mapPkGuia); 
        
        SQLTemplate sqlTempGuia = new SQLTemplate(Guia.class, "select max(num_guia) num_guia from guia");
        sqlTempGuia.setFetchingDataRows(true);                
        List<DataRow> listRowTempGuia = context.performQuery(sqlTempGuia);
        Integer numGuia = (Integer) listRowTempGuia.get(0).get("NUM_GUIA");                        
                
        Guia guia = null;
        if(guia_==null){                    
            numGuia++;
            guia = (Guia) context.newObject(Guia.class);
        }else{
            guia = guia_;
        }
        
        Situacao situacao = null;
        if (temCarencia) {
            situacao = (Situacao) DataObjectUtils.objectForPK(context, Situacao.class, Situacao.SITUACAO_EM_AUTORIZACAO);

            guia.setToUsuarioAutorizadoSolicita(usuarioAutorizado);
            guia.setDataSolicitacaoWeb(datEmissao);
        } else {
            situacao = (Situacao) DataObjectUtils.objectForPK(context, Situacao.class, Situacao.SITUACAO_EM_ABERTO);

            guia.setToUsuarioAutorizado(usuarioAutorizado);
        }

        try {
            guia.setNumGuia(numGuia);
            guia.setToEspecialidade(null);
            guia.setMatServidor(beneficiario.getMatServidor());
            guia.setCodDepend(beneficiario.getCodDepend());
            guia.setDatEmissao(datEmissao);
            guia.setToCredenciado(usuarioAutorizado.getToCredenciadoAutorizado().getToCredenciado());
            guia.setCodTipoGuia(tipoGuia.getCodTipGuia());
            guia.setToTipoGuia(tipoGuia);
            guia.setToSituacao(situacao);
            guia.setFuncao(beneficiario.getToTitular().getFuncao());
            guia.setCusteio(tipoGuia.getCusteio());
            guia.setToSituacaoFuncional(beneficiario.getToTitular().getToSituacaoFuncional());
            guia.setToOrigemGuia(origemGuia);
            guia.setIndPagAtend(false);
            guia.setIndDespesaHospitalar(true);
            guia.setIndApartamento(indApartamento == 1 ? true : false);
            guia.setIndUrgencia(false);
            guia.setIndInternacao(indInternacao == 1 ? true : false);
            guia.setAnoExercicio(guia.getAnoVigente(context));
            guia.setObsDespesa(descricao);
            guia.setTotal(new Double(buscaValorPadraoGuia()));

            context.commitChanges();
        } catch (Exception e) {
            context.rollbackChanges();
            throw new ServletException(e);
        }

        req.setAttribute("guia", guia);        
        req.setAttribute("EM_ABERTO", Situacao.SITUACAO_EM_ABERTO);
        req.setAttribute("REJEITADA", Situacao.SITUACAO_REJEITADA);
        req.setAttribute("CANCELADA", Situacao.SITUACAO_CANCELADA);                
        req.setAttribute("AUTORIZADA", Situacao.SITUACAO_AUTORIZADA);
        req.setAttribute("EM_AUTORIZACAO", Situacao.SITUACAO_EM_AUTORIZACAO);
        req.setAttribute("situacaoGuia", guia.getToSituacao().getCodSituacao());

        RequestDispatcher view = req.getRequestDispatcher("/restrita/user/guiaMedicamento/emissao/sucesso.jsp");
        view.forward(req, resp);
    }

    private String buscaValorPadraoGuia() throws ServletException {
        try {
            return (String) Util.getEnvVariable("valorGuiaMedicamento");
        } catch (NamingException ex) {
            throw new ServletException("TreSaudeUser GuiaMedicamento.Emissao.buscaValorPadraoGuia(). Erro ao recuperar valor da guia.\n", ex);
        }
    }
}