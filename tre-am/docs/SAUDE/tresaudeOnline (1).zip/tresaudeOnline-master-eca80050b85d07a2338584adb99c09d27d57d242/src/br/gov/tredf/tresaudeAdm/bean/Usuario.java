package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._Usuario;

public class Usuario extends _Usuario {
     public String getUserName() {
        return (getObjectId() != null && !getObjectId().isTemporary())
            ? (String)getObjectId().getIdSnapshot().get(USERNAME_PK_COLUMN)
            : null;
    }

}
