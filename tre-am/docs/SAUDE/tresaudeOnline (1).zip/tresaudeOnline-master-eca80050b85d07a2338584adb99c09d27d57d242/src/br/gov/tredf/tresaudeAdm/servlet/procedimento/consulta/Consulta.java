/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.servlet.procedimento.consulta;

import br.gov.tredf.tresaudeAdm.bean.Procedimento;
import br.gov.tredf.tresaudeAdm.bean.ProcedimentoAutorizado;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;


/**
 * @author Camila Kinoshita
 */

public class Consulta extends HttpServlet {

    private final String TRUE = "TRUE";
    private final String FALSE = "FALSE";

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher view = null;
        view = req.getRequestDispatcher("/restrita/user/procedimento/consulta.jsp");
        req.setAttribute("titulo", "Consulta de Procedimentos");

        DataContext context = ServletUtil.getSessionContext(req.getSession());
        String codUsuario = req.getRemoteUser();
        if (codUsuario == null || codUsuario.equals("")) {
            throw new ServletException("C�digo do usu�rio est� com o valor nulo ou em branco.");
        }
        UsuarioAutorizado usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, codUsuario);
        req.setAttribute("usuarioAutorizado", usuarioAutorizado);
        
        String buscarApenasProcedimentosAutorizados = req.getParameter("buscarApenasProcedimentosAutorizados");
        String ehBuscaTextual = req.getParameter("ehBuscaTextual");
        String codNomProcedimento = req.getParameter("codNomProcedimento");

        boolean primeiraVez = false;
        if(buscarApenasProcedimentosAutorizados==null || ehBuscaTextual==null){
            req.setAttribute("buscarApenasProcedimentosAutorizados", TRUE);
            buscarApenasProcedimentosAutorizados = TRUE;
            req.setAttribute("ehBuscaTextual", FALSE);
            ehBuscaTextual = FALSE;
            primeiraVez = true;
        }else{
            req.setAttribute("buscarApenasProcedimentosAutorizados", buscarApenasProcedimentosAutorizados);
            req.setAttribute("ehBuscaTextual", ehBuscaTextual);
        }
        
        req.setAttribute("codNomProcedimento", codNomProcedimento);

        //Quando � a primeira vez n�o realiza a busca
        if(!primeiraVez){
            Integer codTabela = usuarioAutorizado.getToCredenciadoAutorizado().getToCredenciado().getToTabela().getCodTabela();
            Procedimento procedimento;
            List<Procedimento> listProcedimento = null;

            if(buscarApenasProcedimentosAutorizados.trim().equals(TRUE)){
                if(ehBuscaTextual.trim().equals(TRUE)){
                    if(codNomProcedimento!=null && codNomProcedimento.length()>2){
                        procedimento = getProcedimentoAutorizado(context, codTabela, codNomProcedimento);
                        if (procedimento == null) {
                            listProcedimento = getProcedimentoAutorizadoArray(context, codTabela, codNomProcedimento);
                        } else {
                            listProcedimento = new ArrayList<Procedimento>();
                            listProcedimento.add(procedimento);
                        }
                    }else{
                        listProcedimento = new ArrayList<Procedimento>();
                    }
                } else {
                    listProcedimento = getTodosProcedimentoAutorizadoArray(context, codTabela);
                }
            }

            if(buscarApenasProcedimentosAutorizados.trim().equals(FALSE)){
                if(ehBuscaTextual.trim().equals(TRUE)){
                    if(codNomProcedimento!=null && codNomProcedimento.length()>2){
                        procedimento = getProcedimento(context, codTabela, codNomProcedimento);
                        if (procedimento == null) {
                            listProcedimento = getProcedimentoArray(context, codTabela, codNomProcedimento);
                        } else {
                            listProcedimento = new ArrayList<Procedimento>();
                            listProcedimento.add(procedimento);
                        }
                    }else{
                        listProcedimento = new ArrayList<Procedimento>();
                    }
                } else {
                    listProcedimento = getTodosProcedimentoArray(context, codTabela);
                }
            }

            req.setAttribute("listProcedimento", listProcedimento);
            if(listProcedimento!=null){
                req.setAttribute("numElementos", listProcedimento.isEmpty()?"0":Integer.toString(listProcedimento.size()));
            }
        }
            
        view.forward(req, resp);
    }

    private Procedimento getProcedimentoAutorizado(DataContext context, Integer codTabela, String codProcedimento) {
        Map<String, Object> mapPk = new HashMap<String, Object>();
        mapPk.put(ProcedimentoAutorizado.COD_PROCEDIMENTO_PK_COLUMN, codProcedimento);
        mapPk.put(ProcedimentoAutorizado.COD_TABELA_PK_COLUMN, codTabela);
        ProcedimentoAutorizado procedimentoAutorizado = (ProcedimentoAutorizado) DataObjectUtils.objectForPK(context, ProcedimentoAutorizado.class, mapPk);
        if (procedimentoAutorizado == null) {
            return null;
        } else {
            return procedimentoAutorizado.getToProcedimento();
        }
    }

    private List<Procedimento> getProcedimentoAutorizadoArray(DataContext context, Integer codTabela, String nomProcedimento) {
        Expression expProcedimento = ExpressionFactory.matchDbExp(Procedimento.COD_TABELA_PK_COLUMN, codTabela);
        expProcedimento = expProcedimento.andExp(ExpressionFactory.likeIgnoreCaseExp(Procedimento.NOM_PROCEDIMENTO_PROPERTY, "%" + nomProcedimento + "%"));
        SelectQuery queryProcedimento = new SelectQuery(Procedimento.class, expProcedimento);
        queryProcedimento.addOrdering(Procedimento.NOM_PROCEDIMENTO_PROPERTY, true);
        return context.performQuery(queryProcedimento);
    }

    private Procedimento getProcedimento(DataContext context, Integer codTabela, String codProcedimento) {
        Map<String, Object> mapPk = new HashMap<String, Object>();
        mapPk.put(Procedimento.COD_PROCEDIMENTO_PK_COLUMN, codProcedimento);
        mapPk.put(Procedimento.COD_TABELA_PK_COLUMN, codTabela);
        Procedimento procedimento = (Procedimento) DataObjectUtils.objectForPK(context, Procedimento.class, mapPk);
        if (procedimento == null) {
            return null;
        } else {
            return procedimento;
        }
    }

    private List<Procedimento> getProcedimentoArray(DataContext context, Integer codTabela, String nomProcedimento) {
        Expression expProcedimento = ExpressionFactory.matchDbExp(Procedimento.COD_TABELA_PK_COLUMN, codTabela);
        expProcedimento = expProcedimento.andExp(ExpressionFactory.likeIgnoreCaseExp(Procedimento.NOM_PROCEDIMENTO_PROPERTY, "%" + nomProcedimento + "%"));
        SelectQuery queryProcedimento = new SelectQuery(Procedimento.class, expProcedimento);
        queryProcedimento.addOrdering(Procedimento.NOM_PROCEDIMENTO_PROPERTY, true);
        return context.performQuery(queryProcedimento);
    }

    private List<Procedimento> getTodosProcedimentoArray(DataContext context, Integer codTabela) {
        Expression expProcedimento = ExpressionFactory.matchDbExp(Procedimento.COD_TABELA_PK_COLUMN, codTabela);
        SelectQuery queryProcedimento = new SelectQuery(Procedimento.class, expProcedimento);
        queryProcedimento.addOrdering(Procedimento.NOM_PROCEDIMENTO_PROPERTY, true);
        return context.performQuery(queryProcedimento);
    }

    private List<Procedimento> getTodosProcedimentoAutorizadoArray(DataContext context, Integer codTabela) {
        Expression expProcedimento = ExpressionFactory.matchDbExp(Procedimento.COD_TABELA_PK_COLUMN, codTabela);
        SelectQuery queryProcedimento = new SelectQuery(Procedimento.class, expProcedimento);
        queryProcedimento.addOrdering(Procedimento.NOM_PROCEDIMENTO_PROPERTY, true);
        return context.performQuery(queryProcedimento);
    }

}