package br.gov.tredf.tresaudeAdm.utils;

/**
 * @author Camila Kinoshita
 */

public class StringMethods1 {

   public StringMethods1() {
   }

   public static String primeirasLetrasMaiusculas(String texto){
        /* *
        * Fun��o transforma as primeiras letras de cada palavra digitada em Mai�scula
        * @Alexandre e Camila
        * @version 1.00 2008/3/27
        */
        String resultado="";
        if (texto!=null && !texto.equals("")) {
           texto = texto.toLowerCase();
           String [] palavras = texto.split(" ");
           String str1 = "";
           for(int i=0;i<palavras.length;i++){
              if (!mantemMinusculo(palavras[i])) {

                str1 = palavras[i].substring(0,1);
                char[] c = str1.toCharArray();
                if(c[0]>96 && c[0]<123){
                    palavras[i] = palavras[i].replaceFirst(str1, str1.toUpperCase());
                }
              }
              resultado = resultado + palavras[i];
              if (i<palavras.length-1) resultado = resultado + " ";
           }
        }
        return resultado;
    }

   private static boolean mantemMinusculo(String palavra) {

      if (palavra.equals("da")) return true;
      if (palavra.equals("de")) return true;
      if (palavra.equals("do")) return true;
      if (palavra.equals("e")) return true;
      if (palavra.equals("�")) return true;
      if (palavra.equals("�s")) return true;
      if (palavra.equals("aos")) return true;
      if (palavra.equals("ao")) return true;
      if (palavra.equals("a")) return true;
      if (palavra.equals("o")) return true;
      if (palavra.equals("as")) return true;
      if (palavra.equals("os")) return true;
      if (palavra.equals("dos")) return true;
      if (palavra.equals("das")) return true;
      return false;
   }

   public static String primeiraPalavra(String texto){
	return primeirasLetrasMaiusculas(texto.substring(0,texto.indexOf (" ")));
   }

   public static String maiusculoSemAcento (String texto){
        String resultado="";
        if (texto!=null && !texto.equals("")) {
           texto = texto.toUpperCase();
           texto = texto.replaceAll("�", "A");
           texto = texto.replaceAll("�", "A");
           texto = texto.replaceAll("�", "A");
           texto = texto.replaceAll("�", "A");
           texto = texto.replaceAll("�", "A");
           texto = texto.replaceAll("�", "E");
           texto = texto.replaceAll("�", "E");
           texto = texto.replaceAll("�", "E");
           texto = texto.replaceAll("�", "E");
           texto = texto.replaceAll("�", "I");
           texto = texto.replaceAll("�", "I");
           texto = texto.replaceAll("�", "I");
           texto = texto.replaceAll("�", "I");
           texto = texto.replaceAll("�", "O");
           texto = texto.replaceAll("�", "O");
           texto = texto.replaceAll("�", "O");
           texto = texto.replaceAll("�", "O");
           texto = texto.replaceAll("�", "O");
           texto = texto.replaceAll("�", "U");
           texto = texto.replaceAll("�", "U");
           texto = texto.replaceAll("�", "U");
           texto = texto.replaceAll("�", "U");
           resultado = texto;
        }
        return resultado;
   }

}