package br.gov.tredf.tresaudeAdm.utils;

import java.util.Calendar;
import java.util.Enumeration;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * @author Camila Kinoshita
 * 02/09/2014
 */
public class Debug {

    public static final String APP_NAME = "tresaudeUser";

    public static final int INICIO = 0;
    public static final int FIM = 1;

    public static boolean SHOW_DEBUG_TRACE = false;
    public static boolean SHOW_DEBUG_MESSAGES = false;


    /**
     * Inclui uma mensagem de Log de in�cio e fim de m�todo sem imprimir o CPF do usu�rio.
     * @param status
     */
    public static void debug(int status) {
        if (SHOW_DEBUG_TRACE) {
            String strStatus = null;
            if (status == INICIO) {
                strStatus = "Iniciando";
            }
            if (status == FIM) {
                strStatus = "Finalizando";
            }

            StackTraceElement stackTraceElement = new Throwable().getStackTrace()[1];
        
            System.out.println(APP_NAME+" DEBUG_TRACE: " + strStatus + " metodo "
                + "[class= " + stackTraceElement.getClassName()
                + ", method-name= " + stackTraceElement.getMethodName() + "()]");
        }
    }

    /**
     * Imprime uma mensagem
     * @param msg
     */
    public static void debug(String msg) {
        if (SHOW_DEBUG_MESSAGES) {
            System.out.println(APP_NAME+" DEBUG_MSG: " + msg);
        }
    }

    /**
     * Inclui uma mensagem de erro no console.
     * @param msg
     */
    public static void error(String error) {
        StackTraceElement stackTraceElement = new Throwable().getStackTrace()[1];
        System.out.println(APP_NAME+" ERROR " + Debug.getDataHoraFormatado());
        System.out.println("DEBUG_ERROR: " + error +
            " metodo " + "[class= " + stackTraceElement.getClassName() +
            ", method-name= " + stackTraceElement.getMethodName() + "()]");
    }

    /**
     * Imprime o stackTrace de uma exce��o.
     * @param msg
     */
    public static void error(Exception exception) {
        StackTraceElement stackTraceElement = new Throwable().getStackTrace()[1];
        System.out.println(APP_NAME+" ERROR " + Debug.getDataHoraFormatado());
        System.out.println(APP_NAME+" DEBUG_ERROR: " + exception.getMessage() +
            " metodo " + "[class= " + stackTraceElement.getClassName() +
            ", method-name= " + stackTraceElement.getMethodName() + "()]");
        exception.printStackTrace();
    }

    private static String getDataHoraFormatado(){
        Calendar cal = Calendar.getInstance();
        return cal.get(Calendar.DAY_OF_MONTH)+"/"+(cal.get(Calendar.MONTH) + 1)+"/"+cal.get(Calendar.YEAR)+" "+cal.get(Calendar.HOUR_OF_DAY)+":"+cal.get(Calendar.MINUTE)+":"+cal.get(Calendar.SECOND);
    }

    public static void imprimirParametrosAtributos(HttpServletRequest request) {
        imprimirParametros(request);
        imprimirAtributos(request);
        imprimirAtributosSessao(request);
    }

    public static void imprimirParametros(HttpServletRequest request) {
        if (SHOW_DEBUG_MESSAGES) {
            Debug.debug("================");
            Enumeration en = null;
            en = request.getParameterNames();
            Debug.debug("PARAMETROS");
            while (en.hasMoreElements()) {
                Object o = en.nextElement();
                Debug.debug(o + ": " + request.getParameter(o.toString()));
            }
            Debug.debug("================");
        }
    }

    public static void imprimirAtributos(HttpServletRequest request) {
        if (SHOW_DEBUG_MESSAGES) {
            Debug.debug("================");
            Enumeration en = null;
            en = request.getAttributeNames();
            Debug.debug("ATRIBUTOS");
            while (en.hasMoreElements()) {
                Object o = en.nextElement();
                Debug.debug(o + ": " + request.getAttribute(o.toString()));
            }
            Debug.debug("================");
        }
    }

    public static void imprimirAtributosSessao(HttpServletRequest request) {
        if (SHOW_DEBUG_MESSAGES) {
            Debug.debug("======== imprimirAtributosSessao ========");
            HttpSession session = request.getSession();
            Enumeration en = null;
            en = session.getAttributeNames();
            Debug.debug("ATRIBUTOS");
            while (en.hasMoreElements()) {
                Object o = en.nextElement();
                Debug.debug(o + ": " + request.getAttribute(o.toString()));
            }
            Debug.debug("================");
        }
    }
 
    
}