package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._Guia;
import java.util.List;
import org.apache.cayenne.DataRow;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SQLTemplate;
import org.apache.cayenne.query.SelectQuery;

public class Guia extends _Guia {
    private Beneficiario beneficiario = null;

    public Integer getNumGuia() {
        return (getObjectId() != null && !getObjectId().isTemporary())
            ? (Integer)getObjectId().getIdSnapshot().get(NUM_GUIA_PK_COLUMN)
            : null;
    }

    public Beneficiario getToBeneficiario() throws Exception {
        if (beneficiario == null) {
            DataContext context = this.getDataContext();
            Expression expBeneficiario = ExpressionFactory.matchDbExp(Beneficiario.MAT_SERVIDOR_PK_COLUMN, getMatServidor());
            expBeneficiario = expBeneficiario.andExp(ExpressionFactory.matchExp(Beneficiario.COD_DEPEND_PROPERTY, getCodDepend()));
            SelectQuery queryBeneficiario = new SelectQuery(Beneficiario.class, expBeneficiario);
            List<Beneficiario> listBeneficiario = context.performQuery(queryBeneficiario);
            if (listBeneficiario.size() == 1) {
                beneficiario = listBeneficiario.get(0);
            } else {
                throw new Exception("N�o foi poss�vel localizar o benefici�rio");
            }
        }
        return beneficiario;
    }

    public String getNumAnoGuia() {
        String retorno = "";
        retorno += String.format("%06d", getNumGuia());
        retorno += "/";
        retorno += getAnoExercicio().substring(2, 4);
        return retorno;
    }
    
    public String getAnoVigente(DataContext context){
        Integer ano = 2000;
        
        String sql =  "select exercicio_vigente ano from parametros" ;
        
        SQLTemplate sqlTemp = new SQLTemplate(Procedimento.class, sql);
        sqlTemp.setFetchingDataRows(true);
        List<DataRow> drResultado = context.performQuery(sqlTemp);
        
        for (DataRow dr : drResultado) {
            ano = (Integer) dr.get("ANO");
        }
        
        String str_ano = ano.toString();
        
        return str_ano;
    }
    
}
