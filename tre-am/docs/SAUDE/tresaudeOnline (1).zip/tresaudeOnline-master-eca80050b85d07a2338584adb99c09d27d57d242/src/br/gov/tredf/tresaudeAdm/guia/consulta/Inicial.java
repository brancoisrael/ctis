/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.guia.consulta;

import br.gov.tredf.tresaudeAdm.bean.OrigemGuia;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;

/**
 * @author Camila Kinoshita
 */

public class Inicial extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String titulo = "Consultar Guia";
        req.setAttribute("titulo", titulo);

        String codUsuario = req.getRemoteUser();
        DataContext context = ServletUtil.getSessionContext(req.getSession());

        UsuarioAutorizado usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, codUsuario);
        req.setAttribute("usuarioAutorizado", usuarioAutorizado);

        OrigemGuia origemGuia = (OrigemGuia) DataObjectUtils.objectForPK(context, OrigemGuia.class, OrigemGuia.GUIAS_ON_LINE);
        req.setAttribute("origemGuia", origemGuia);

        Calendar calendar = Calendar.getInstance();
        String ano = calendar.get(Calendar.YEAR)+"";
        req.setAttribute("ano", ano);

        RequestDispatcher view = req.getRequestDispatcher("/restrita/user/guia/consulta/inicial.jsp");
        view.forward(req, resp);
    }


}