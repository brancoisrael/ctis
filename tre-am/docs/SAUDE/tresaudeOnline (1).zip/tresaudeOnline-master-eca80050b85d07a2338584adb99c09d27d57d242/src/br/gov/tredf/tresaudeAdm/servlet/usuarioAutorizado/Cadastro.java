/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.gov.tredf.tresaudeAdm.servlet.usuarioAutorizado;

import br.gov.tredf.tresaudeAdm.bean.CredenciadoAutorizado;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import br.gov.tredf.tresaudeAdm.utils.CriptoMD5;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;

/**
 *
 * @author igor
 */
public class Cadastro extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String titulo = null;
        titulo = "Usu�rio cadastrado com sucesso";
        req.setAttribute("titulo", titulo);

        String tipo = req.getParameter("tipo");
        String codUsuario = req.getParameter("codUsuario");
        String nomUsuario = req.getParameter("nomUsuario");
        Integer codCredenciado = new Integer(req.getRemoteUser());
        String senha = req.getParameter("senha");
        String senhaConfirma = req.getParameter("senhaConfirma");
        String strBloqueado = req.getParameter("bloqueado");
        Boolean bloqueado = null;
        Date datUltAtual = Calendar.getInstance().getTime();
        String perfil = "USER";

        if (tipo == null) {
            tipo = "I";
        } else if (tipo.equals("")) {
            tipo = "I";
        }

        if (strBloqueado != null) {
            if (strBloqueado.equals("1")) {
                bloqueado = true;
            } else {
                bloqueado = false;
            }
        }

        if (codUsuario == null || codUsuario.equals("")) {
            throw new ServletException("Login � campo obrigat�rio");
        }

        if (codUsuario.contains(" ")) {
            throw new ServletException("O campo Login n�o pode conter caracteres em branco");
        }

        if (nomUsuario == null || nomUsuario.equals("")) {
            throw new ServletException("Nome � campo obrigat�rio");
        }

        if (senha == null || senha.equals("")) {
            throw new ServletException("Senha � campo obrigat�rio");
        }

        if (senhaConfirma == null || senhaConfirma.equals("")) {
            throw new ServletException("Confirma��o de senha � campo obrigat�rio");
        }

        if (!senha.equals(senhaConfirma)) {
            throw new ServletException("Confirma��o de senha deve ser igual � senha");
        }

        if (bloqueado == null) {
            throw new ServletException("Bloqueado � campo obrigat�rio");
        }

        DataContext context = ServletUtil.getSessionContext(req.getSession());
        CredenciadoAutorizado credenciado = (CredenciadoAutorizado) DataObjectUtils.objectForPK(context, CredenciadoAutorizado.class, codCredenciado);

        UsuarioAutorizado usuarioAutorizado = null;

        try {

            if (tipo.equals("I")) {
                usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, codUsuario);
                if (usuarioAutorizado != null) {
                    throw new ServletException("J� existe um usu�rio com este login.");
                } else {
                    usuarioAutorizado = (UsuarioAutorizado) context.newObject(UsuarioAutorizado.class);
                    usuarioAutorizado.setCodUsuario(codUsuario);
                }
            } else if (tipo.equals("A") || tipo.equals("E")) {
                usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, codUsuario);
            } else {
                throw new ServletException("Tipo de opera��o inv�lida");
            }

            if (tipo.equals("E")) {
                titulo = "Usu�rio exclu�do com sucesso";
                context.deleteObject(usuarioAutorizado);
            } else {
                titulo = "Usu�rio cadastrado com sucesso";
                usuarioAutorizado.setNomUsuario(nomUsuario);
                usuarioAutorizado.setToCredenciadoAutorizado(credenciado);
                if (!senha.equals(usuarioAutorizado.SENHA_PADRAO))
                    usuarioAutorizado.setSenhaMd5(CriptoMD5.cripto(senha));
                usuarioAutorizado.setBloqueado(bloqueado);
                if (usuarioAutorizado.getBloqueado()) {
                    usuarioAutorizado.setCodUsuarioLogin(null);
                    usuarioAutorizado.setSenhaMd5Login(null);
                } else {
                    usuarioAutorizado.setCodUsuarioLogin(usuarioAutorizado.getCodUsuario());
                    usuarioAutorizado.setSenhaMd5Login(usuarioAutorizado.getSenhaMd5());
                }
                usuarioAutorizado.setDatUltAtual(datUltAtual);
                usuarioAutorizado.setPerfil(perfil);
            }
            req.setAttribute("titulo", titulo);

            context.commitChanges();

        } catch (Exception e) {
            context.rollbackChanges();
            throw new ServletException(e);
        }

        if (tipo.equals("I") || tipo.equals("A"))
            req.setAttribute("usuarioAutorizado", usuarioAutorizado);

        RequestDispatcher view = req.getRequestDispatcher("/restrita/adm/usuarioAutorizado/sucesso.jsp");
        view.forward(req, resp);
    }

}
