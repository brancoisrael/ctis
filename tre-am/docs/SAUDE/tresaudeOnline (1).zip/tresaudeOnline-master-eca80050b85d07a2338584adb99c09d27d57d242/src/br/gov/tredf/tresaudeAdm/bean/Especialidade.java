package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._Especialidade;

public class Especialidade extends _Especialidade {

    public Integer getCodEspecialidade() {
        return (getObjectId() != null && !getObjectId().isTemporary())
            ? (Integer)getObjectId().getIdSnapshot().get(COD_ESPECIALIDADE_PK_COLUMN)
            : null;
    }
    
}
