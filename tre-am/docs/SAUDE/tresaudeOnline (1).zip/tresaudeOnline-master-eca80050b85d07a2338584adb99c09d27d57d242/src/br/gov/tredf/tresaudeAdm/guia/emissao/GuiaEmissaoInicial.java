/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.guia.emissao;

import br.gov.tredf.tresaudeAdm.bean.Especialidade;
import br.gov.tredf.tresaudeAdm.bean.TipoGuia;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import br.gov.tredf.tresaudeAdm.utils.DataUtil;
import br.gov.tredf.tresaudeAdm.utils.Util;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.List;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;
import org.apache.cayenne.query.SelectQuery;

/**
 *
 * @author igor
 */
public class GuiaEmissaoInicial extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
         String titulo = "Emiss�o de Guia";
        req.setAttribute("titulo", titulo);

        req.setAttribute("tipoProcedimento", "PROCEDIMENTOS_AUTORIZADOS");
        req.setAttribute("situacaoGuia", "EM_ABERTO");

        String codUsuario = req.getRemoteUser();
        
        if (codUsuario == null || codUsuario.equals("")) {
            throw new ServletException("C�digo do usu�rio est� com o valor nulo ou em branco.");
        }

        DataContext context = ServletUtil.getSessionContext(req.getSession());

        TipoGuia tipoGuia = (TipoGuia) DataObjectUtils.objectForPK(context, TipoGuia.class, TipoGuia.GUIA_MEDICA_CLINICA_LABORATORIAL);
        req.setAttribute("tipoGuia", tipoGuia);

        UsuarioAutorizado usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, codUsuario);
        req.setAttribute("usuarioAutorizado", usuarioAutorizado);

        SelectQuery queryEspecialidade = new SelectQuery(Especialidade.class);
        queryEspecialidade.addOrdering(Especialidade.NOM_ESPECIALIDADE_PROPERTY, true);
        List<Especialidade> listEspecialidade = context.performQuery(queryEspecialidade);
        req.setAttribute("listEspecialidade", listEspecialidade);
        this.buscaPercentuaisAcrescimo(req);
        this.verificaHorarioUrgencia(req);

        RequestDispatcher view = req.getRequestDispatcher("/restrita/user/guia/emissao/emissao.jsp");
        view.forward(req, resp);
    }
    private void buscaPercentuaisAcrescimo(HttpServletRequest req) throws ServletException{
        try {
            Double percUrgencia = (Double) Util.getEnvVariable("percAcrescimoUrgencia") / 100;
            req.setAttribute("percAcrescimoUrgencia", percUrgencia);
        } catch (NamingException ex) {
            throw new ServletException("TreSaude Emissao.Inicial.buscaPercentuaisAcrescimo(). Erro ao recuperar percentual de Urg�ncia.\n", ex);
        }
    }

    private void verificaHorarioUrgencia(HttpServletRequest req){
        String ehHorarioUrgencia = "0";
        Calendar calendar = Calendar.getInstance();
        int hora = calendar.get(Calendar.HOUR_OF_DAY);
        DataUtil dataUtil = new DataUtil();
        if(!dataUtil.ehDiaUtil(calendar.getTimeInMillis())){
            ehHorarioUrgencia = "1";
        } else {
            if(hora>=22 || hora<6){
                ehHorarioUrgencia = "1";
            }
        }
        req.setAttribute("ehHorarioUrgencia", ehHorarioUrgencia);
    }
   
}
