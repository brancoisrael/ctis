/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.gov.tredf.tresaudeAdm.filter;

import br.gov.tredf.tresaudeAdm.bean.CredenciadoAutorizado;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import java.io.IOException;
import java.util.Calendar;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.ObjectId;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;
import org.apache.cayenne.query.ObjectIdQuery;



public class Seguranca implements Filter {

    public void init(FilterConfig config) throws ServletException {
        
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpReq = (HttpServletRequest)req;
        String remoteUser = httpReq.getRemoteUser();
        
        if (remoteUser == null) {
            RequestDispatcher view = req.getRequestDispatcher("/login/login.jsp");
            view.forward(req, resp);
        } else {
            DataContext context = ServletUtil.getSessionContext(httpReq.getSession());
            ObjectId id = null;
            ObjectIdQuery query = null;
            
            Integer codCredenciado=0;
            CredenciadoAutorizado credenciadoAutorizado=null;
            UsuarioAutorizado usuarioAutorizado=null;
            
            usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, remoteUser);                

			/*
			 * try{ codCredenciado = new Integer(remoteUser); }catch(NumberFormatException
			 * ne){ ne.printStackTrace(); }
			 */
            
            credenciadoAutorizado = usuarioAutorizado.getToCredenciadoAutorizado();

            if(credenciadoAutorizado!=null){
                id = credenciadoAutorizado.getObjectId();
                query = new ObjectIdQuery(id, false, ObjectIdQuery.CACHE_REFRESH);
                DataObjectUtils.objectForQuery(context, query);

                id = credenciadoAutorizado.getToCredenciado().getObjectId();
                query = new ObjectIdQuery(id, false, ObjectIdQuery.CACHE_REFRESH);
                DataObjectUtils.objectForQuery(context, query);

                if (credenciadoAutorizado.getBloqueado()) {
                    throw new ServletException("Credenciado bloqueado");
                } else if (credenciadoAutorizado.getToCredenciado().getDatValidadeContrato().before(Calendar.getInstance().getTime())) {
                    Calendar validade = Calendar.getInstance();
                    validade.setTime(credenciadoAutorizado.getToCredenciado().getDatValidadeContrato());
                    Integer dia = validade.get(Calendar.DAY_OF_MONTH);
                    Integer mes = validade.get(Calendar.MONTH) + 1;
                    Integer ano = validade.get(Calendar.YEAR);
                    String datValidadeContrato = dia.toString() + "/" + mes.toString() + "/" + ano.toString();
                    throw new ServletException("Data de v�lidade do contrato (" + datValidadeContrato + ") expirada");
                } else if (credenciadoAutorizado.getToCredenciado().getContratoRevogado()) {
                    throw new ServletException("O contrato est� revogado");
                } else {
                    chain.doFilter(req, resp);
                }    
            }else{
                
                id = usuarioAutorizado.getObjectId();
                query = new ObjectIdQuery(id, false, ObjectIdQuery.CACHE_REFRESH);
                DataObjectUtils.objectForQuery(context, query);

                id = usuarioAutorizado.getToCredenciadoAutorizado().getObjectId();
                query = new ObjectIdQuery(id, false, ObjectIdQuery.CACHE_REFRESH);
                DataObjectUtils.objectForQuery(context, query);

                id = usuarioAutorizado.getToCredenciadoAutorizado().getToCredenciado().getObjectId();
                query = new ObjectIdQuery(id, false, ObjectIdQuery.CACHE_REFRESH);
                DataObjectUtils.objectForQuery(context, query);

                if (usuarioAutorizado.getBloqueado()) {
                    throw new ServletException("Usu�rio bloqueado");
                } else if (usuarioAutorizado.getToCredenciadoAutorizado().getBloqueado()) {
                    throw new ServletException("Credenciado bloqueado");
                } else if (usuarioAutorizado.getToCredenciadoAutorizado().getToCredenciado().getDatValidadeContrato().before(Calendar.getInstance().getTime())) {
                    Calendar validade = Calendar.getInstance();
                    validade.setTime(usuarioAutorizado.getToCredenciadoAutorizado().getToCredenciado().getDatValidadeContrato());
                    Integer dia = validade.get(Calendar.DAY_OF_MONTH);
                    Integer mes = validade.get(Calendar.MONTH) + 1;
                    Integer ano = validade.get(Calendar.YEAR);
                    String datValidadeContrato = dia.toString() + "/" + mes.toString() + "/" + ano.toString();
                    throw new ServletException("Data de v�lidade do contrato (" + datValidadeContrato + ") expirada");
                } else if (usuarioAutorizado.getToCredenciadoAutorizado().getToCredenciado().getContratoRevogado()) {
                    throw new ServletException("O contrato est� revogado");
                } else {
                    chain.doFilter(req, resp);
                }
            }
        } 
    }

    public void destroy() {
        
    }
    
    public boolean isDigit(String matricula) {
        return matricula.matches("[0-9]*");
    }
    
}