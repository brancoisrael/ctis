/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.gov.tredf.tresaudeAdm.servlet.usuarioAutorizado;

import br.gov.tredf.tresaudeAdm.bean.CredenciadoAutorizado;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import br.gov.tredf.tresaudeAdm.utils.Util;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;

/**
 *
 * @author igor
 */
public class Tela extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String titulo = "Cadastro de Usu�rios";
        req.setAttribute("titulo", titulo);

        processarConsulta(req, resp);

        RequestDispatcher view = req.getRequestDispatcher("/restrita/adm/usuarioAutorizado/cadastro.jsp");
        view.forward(req, resp);

    }

    private void processarConsulta(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String codUsuario = codUsuario = req.getParameter("codUsuario");


        if (codUsuario != null) {
            DataContext context = ServletUtil.getSessionContext(req.getSession());
            UsuarioAutorizado usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, codUsuario);
            
            req.setAttribute("usuarioAutorizado", usuarioAutorizado);
        }

    }
}
