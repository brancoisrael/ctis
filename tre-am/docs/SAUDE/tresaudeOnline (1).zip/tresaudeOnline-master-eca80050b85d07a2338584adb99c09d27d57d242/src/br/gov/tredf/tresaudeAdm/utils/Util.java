/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.utils;

import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author igor
 */
public class Util {

    public static Object getEnvVariable(String var) throws NamingException {
        InitialContext ctx = new InitialContext();
        return ctx.lookup("java:comp/env/" + var);
    }
    
    public static boolean isDigit(String matricula) {
        return matricula.matches("[0-9]*");
    }
}
