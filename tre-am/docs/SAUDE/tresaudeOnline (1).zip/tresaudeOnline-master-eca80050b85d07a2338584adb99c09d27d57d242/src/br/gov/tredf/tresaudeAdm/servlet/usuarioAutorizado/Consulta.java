/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.gov.tredf.tresaudeAdm.servlet.usuarioAutorizado;

import br.gov.tredf.tresaudeAdm.bean.CredenciadoAutorizado;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import br.gov.tredf.tresaudeAdm.utils.Util;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;

/**
 *
 * @author igor
 */
public class Consulta extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String titulo = "Consulta de Usu�rios";
        req.setAttribute("titulo", titulo);

        Integer codCredenciado = new Integer(req.getRemoteUser());

        Expression exp = ExpressionFactory.matchDbExp(UsuarioAutorizado.TO_CREDENCIADO_AUTORIZADO_PROPERTY, codCredenciado);

        DataContext context = ServletUtil.getSessionContext(req.getSession());

        SelectQuery query = new SelectQuery(UsuarioAutorizado.class, exp);

        List<UsuarioAutorizado> listUsuarioAutorizado = context.performQuery(query);
        if (listUsuarioAutorizado.size() > 0)
            req.setAttribute("listUsuarioAutorizado", listUsuarioAutorizado);

        RequestDispatcher view = req.getRequestDispatcher("/restrita/adm/usuarioAutorizado/consulta.jsp");
        view.forward(req, resp);
    }

}
