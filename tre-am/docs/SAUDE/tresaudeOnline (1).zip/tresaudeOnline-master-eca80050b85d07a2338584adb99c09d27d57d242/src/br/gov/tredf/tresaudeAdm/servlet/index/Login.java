/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.gov.tredf.tresaudeAdm.servlet.index;

import br.gov.tredf.tresaudeAdm.bean.CredenciadoAutorizado;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import br.gov.tredf.tresaudeAdm.utils.Util;
import java.io.IOException;
import java.security.Principal;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;

/**
 *
 * @author igor
 */
public class Login extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        String usuarioLogado = req.getRemoteUser();
        
        DataContext context = ServletUtil.getSessionContext(req.getSession());
        
        String username = (String) req.getSession().getAttribute("j_username");
        String password = (String) req.getSession().getAttribute("j_password");
              
        
        Integer codCredenciado=null;
        CredenciadoAutorizado credenciadoAutorizado=null;
        UsuarioAutorizado usuarioAutorizado=null;
        if(Util.isDigit(usuarioLogado)){
            try{                
                codCredenciado = new Integer(usuarioLogado);
                credenciadoAutorizado = (CredenciadoAutorizado) DataObjectUtils.objectForPK(context, CredenciadoAutorizado.class, codCredenciado);            
            }catch(NumberFormatException ne){
                ne.printStackTrace();
            }            
        }else{
            usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, usuarioLogado);                        
        }
                
        if(credenciadoAutorizado!=null){
            String titulo = "TRE-SA�DE - M�dulo de administra��o";
            req.setAttribute("titulo", titulo);
            req.setAttribute("credenciadoAutorizado", credenciadoAutorizado);            
        }else{
           String titulo = "TRE-SA�DE - M�dulo de emiss�o de guia";
           req.setAttribute("titulo", titulo);
           if (usuarioLogado == null || (usuarioLogado.equals(""))) {
                throw new ServletException("Login do usu�rio est� com valor nulo ou em branco");
            }
            req.setAttribute("usuarioAutorizado", usuarioAutorizado);            
        }
                       
        RequestDispatcher view = req.getRequestDispatcher("/restrita/index.jsp");
        view.forward(req, resp);
    }    

}
