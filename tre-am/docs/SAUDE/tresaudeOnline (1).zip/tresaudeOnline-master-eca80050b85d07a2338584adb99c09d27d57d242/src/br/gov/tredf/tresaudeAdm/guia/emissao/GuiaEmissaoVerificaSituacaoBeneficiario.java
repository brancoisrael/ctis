/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.guia.emissao;

import br.gov.tredf.tresaudeAdm.bean.Beneficiario;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;


/**
 * @author camilak
 */
public class GuiaEmissaoVerificaSituacaoBeneficiario extends HttpServlet {

   @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String matServidor = req.getParameter("matServidor");
        String codDepend = req.getParameter("codDependente");
        if (codDepend != null){
            if(codDepend.equals("") || codDepend.equals("0")){
                codDepend = null;
            }
        }

        if ((matServidor != null) && (!matServidor.equals(""))) {
            DataContext context = ServletUtil.getSessionContext(req.getSession());
            Expression expBeneficiario = ExpressionFactory.matchDbExp(Beneficiario.MAT_SERVIDOR_PK_COLUMN, matServidor);
            expBeneficiario = expBeneficiario.andExp(ExpressionFactory.matchExp(Beneficiario.COD_DEPEND_PROPERTY, codDepend));
            SelectQuery queryBeneficiario = new SelectQuery(Beneficiario.class, expBeneficiario);
            List<Beneficiario> listBeneficiario = context.performQuery(queryBeneficiario);
            Beneficiario beneficiario = null;
            String dados = "";

            if (listBeneficiario.size() != 1) {
                dados="Erro ao tentar recuperar situa��o do benefici�rio.\nMatr�cula:"+matServidor+" Dependente:"+codDepend;
            }  else {
                beneficiario = listBeneficiario.get(0);
            }
            if(dados.equals("")){
                if (beneficiario.getExcluido().equals("S")) {
                    dados="Benefici�rio exclu�do do plano.";
                }
//Comentado por Camila em 01/09/2014
//A carencia do beneficiario eh variavel e depende do procedimento selecionado.
//                if (beneficiario.getCarencia().equals("S")) {
//                    dados="Benefici�rio em per�odo de car�ncia.";
//                }

                if (beneficiario.getSuspenso().equals("S")) {
                    dados="Benefici�rio suspenso temporariamente.";
                }
            }

            resp.setContentType("text/html");
            resp.getWriter().write(dados);
        }
    }
}
