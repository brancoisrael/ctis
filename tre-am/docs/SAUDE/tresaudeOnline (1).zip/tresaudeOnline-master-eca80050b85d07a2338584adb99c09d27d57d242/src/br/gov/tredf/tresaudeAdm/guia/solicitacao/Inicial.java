package br.gov.tredf.tresaudeAdm.guia.solicitacao;

import br.gov.tredf.tresaudeAdm.bean.Especialidade;
import br.gov.tredf.tresaudeAdm.bean.Procedimento;
import br.gov.tredf.tresaudeAdm.bean.TipoGuia;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import br.gov.tredf.tresaudeAdm.utils.Util;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.List;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;

/**
 *
 * @author camila
 */
public class Inicial extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {        
        String titulo = "Solicita��o de Guia";                
        req.setAttribute("titulo", titulo);

        req.setAttribute("tipoProcedimento", "PROCEDIMENTOS_TODOS");
        req.setAttribute("situacaoGuia", "EM_AUTORIZACAO");

        String codUsuario = req.getRemoteUser();

        if (codUsuario == null || codUsuario.equals("")) {
            throw new ServletException("C�digo do usu�rio est� com o valor nulo ou em branco.");
        }

        DataContext context = ServletUtil.getSessionContext(req.getSession());

        TipoGuia tipoGuia = (TipoGuia) DataObjectUtils.objectForPK(context, TipoGuia.class, TipoGuia.GUIA_MEDICA_CLINICA_LABORATORIAL);
        req.setAttribute("tipoGuia", tipoGuia);

        UsuarioAutorizado usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, codUsuario);
        req.setAttribute("usuarioAutorizado", usuarioAutorizado);
        
        Integer codTabela = usuarioAutorizado.getToCredenciadoAutorizado().getToCredenciado().getToTabela().getCodTabela();

        SelectQuery queryEspecialidade = new SelectQuery(Especialidade.class);
        queryEspecialidade.addOrdering(Especialidade.NOM_ESPECIALIDADE_PROPERTY, true);
        List<Especialidade> listEspecialidade = context.performQuery(queryEspecialidade);
        req.setAttribute("listEspecialidade", listEspecialidade);
        this.buscaPercentuaisAcrescimo(req);
        this.verificaHorarioUrgencia(req);
        this.recuperarProcedimentoConsulta(req, codTabela, context);

        RequestDispatcher view = req.getRequestDispatcher("/restrita/user/guia/emissao/emissao.jsp");
        view.forward(req, resp);
    }

    private void buscaPercentuaisAcrescimo(HttpServletRequest req) throws ServletException{
        try {
            Double percUrgencia = (Double) Util.getEnvVariable("percAcrescimoUrgencia") / 100;
            req.setAttribute("percAcrescimoUrgencia", percUrgencia);
        } catch (NamingException ex) {
            throw new ServletException("TreSaudeUser Emissao.Inicial.buscaPercentuaisAcrescimo(). Erro ao recuperar percentual de Urg�ncia.\n", ex);
        }
    }

    private void verificaHorarioUrgencia(HttpServletRequest req){
        String ehHorarioUrgencia = "0";
        Calendar calendar = Calendar.getInstance();
        int hora = calendar.get(Calendar.HOUR_OF_DAY);
        int dia_semana = calendar.get(Calendar.DAY_OF_WEEK);
        if(dia_semana==Calendar.SATURDAY || dia_semana==Calendar.SUNDAY){
            ehHorarioUrgencia = "1";
        } else {
            if(hora>=22 || hora<6){
                ehHorarioUrgencia = "1";
            }
        }
        req.setAttribute("ehHorarioUrgencia", ehHorarioUrgencia);
    }

    private void recuperarProcedimentoConsulta(HttpServletRequest req, Integer cod_tabela, DataContext context) {
        
        // select * from procedimento t where t.cod_especialidade=0 and t.requer_especialidade=1 and t.cod_tabela=14
        Expression exp = null;
        exp = ExpressionFactory.matchExp(Procedimento.COD_ESPECIALIDADE_PROPERTY, 0);
        exp = exp.andExp(ExpressionFactory.matchExp(Procedimento.REQUER_ESPECIALIDADE_PROPERTY, 1));
        exp = exp.andExp(ExpressionFactory.matchDbExp(Procedimento.COD_TABELA_PK_COLUMN, cod_tabela));
        
        SelectQuery select = new SelectQuery(Procedimento.class, exp);
        List<Procedimento> lista = context.performQuery(select);

        if(lista!=null && !lista.isEmpty()){
            DecimalFormat decimalFormat = new DecimalFormat("###,##0.00");
            
            for (Procedimento procedimento: lista) {
                String codProcedimentoConsulta = procedimento.getCodProcedimento().toString();
                String nomProcedimentoConsulta = procedimento.getNomProcedimento();
                String valorProcedimentoConsulta = decimalFormat.format(procedimento.getValorProcedimento());
                String requerEspecialidadeConsulta = procedimento.getRequerEspecialidade().toString();
                req.setAttribute("codProcedimentoConsulta", codProcedimentoConsulta);
                req.setAttribute("nomProcedimentoConsulta", nomProcedimentoConsulta);
                req.setAttribute("valorProcedimentoConsulta", valorProcedimentoConsulta);
                req.setAttribute("requerEspecialidadeConsulta", requerEspecialidadeConsulta);
            }
        }
    }

}
