package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._GuiaProcedimento;

public class GuiaProcedimento extends _GuiaProcedimento {

}
