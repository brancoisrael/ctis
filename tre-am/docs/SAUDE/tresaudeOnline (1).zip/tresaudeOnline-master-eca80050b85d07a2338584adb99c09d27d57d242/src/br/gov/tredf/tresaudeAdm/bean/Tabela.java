package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._Tabela;

public class Tabela extends _Tabela {
    public Integer getCodTabela() {
        return (getObjectId() != null && !getObjectId().isTemporary())
            ? (Integer)getObjectId().getIdSnapshot().get(COD_TABELA_PK_COLUMN)
            : null;
    }
}
