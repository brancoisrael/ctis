/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.tredf.tresaudeAdm.guia.cancelamento;

import br.gov.tredf.tresaudeAdm.bean.Guia;
import br.gov.tredf.tresaudeAdm.bean.OrigemGuia;
import br.gov.tredf.tresaudeAdm.bean.Situacao;
import br.gov.tredf.tresaudeAdm.bean.TipoGuia;
import br.gov.tredf.tresaudeAdm.bean.UsuarioAutorizado;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.conf.ServletUtil;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;

/**
 * @author Camila Kinoshita
 */

public class Cancelamento extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher view = req.getRequestDispatcher("/restrita/user/guia/consulta/inicial.jsp");

        String numGuia = req.getParameter("numGuia2");
        String anoGuia = req.getParameter("anoExercicio2");
        String codUsuario = req.getRemoteUser();

        if( numGuia!=null && !numGuia.trim().equals("") && anoGuia!=null && !anoGuia.trim().equals("") ){
            Object[] tipoGuiaValues = TipoGuia.getTiposDeGuia();
            DataContext context = ServletUtil.getSessionContext(req.getSession());
            UsuarioAutorizado usuarioAutorizado = (UsuarioAutorizado) DataObjectUtils.objectForPK(context, UsuarioAutorizado.class, codUsuario);
            Integer codCredenciado = usuarioAutorizado.getToCredenciadoAutorizado().getCodCredenciado();
            Expression exp = null;
            exp = ExpressionFactory.matchDbExp(Guia.NUM_GUIA_PK_COLUMN, numGuia);
            exp = exp.andExp(ExpressionFactory.matchExp(Guia.ANO_EXERCICIO_PROPERTY, anoGuia));
            exp = exp.andExp(ExpressionFactory.inExp(Guia.TO_TIPO_GUIA_PROPERTY, tipoGuiaValues));
            exp = exp.andExp(ExpressionFactory.matchExp(Guia.TO_ORIGEM_GUIA_PROPERTY, OrigemGuia.GUIAS_ON_LINE));
            exp = exp.andExp(ExpressionFactory.matchExp(Guia.TO_CREDENCIADO_PROPERTY, codCredenciado));
            SelectQuery select = new SelectQuery(Guia.class, exp);
            List<Guia> lista = context.performQuery(select);
            
            
            
            if(lista.size()>0){
                Guia guia = lista.get(0);
                atualizarDadosGuia(guia, context);                
                req.setAttribute("guia", guia);
                req.setAttribute("situacaoGuia", guia.getToSituacao().getCodSituacao());
                req.setAttribute("EM_ABERTO", Situacao.SITUACAO_EM_ABERTO);
                req.setAttribute("REJEITADA", Situacao.SITUACAO_REJEITADA);
                req.setAttribute("CANCELADA", Situacao.SITUACAO_CANCELADA);                
                req.setAttribute("AUTORIZADA", Situacao.SITUACAO_AUTORIZADA);
                req.setAttribute("EM_AUTORIZACAO", Situacao.SITUACAO_EM_AUTORIZACAO);                
                
                if(guia.getToTipoGuia().getCodTipGuia()==TipoGuia.GUIA_MEDICA_CLINICA_LABORATORIAL){
                    view = req.getRequestDispatcher("/restrita/user/guia/emissao/sucesso.jsp");
                } else {
                    String titulo = "Guia Cancelada com Sucesso";
                    req.setAttribute("titulo", titulo);
                    view = req.getRequestDispatcher("/restrita/user/guiaMedicamento/emissao/sucesso.jsp");
                }
                
            } else {
                req.setAttribute("erro", "Guia "+numGuia+"/"+anoGuia+" n�o encontrada.");
            }

        } else {
            boolean erro = false;
            if(numGuia==null || numGuia.trim().equals("")){
                req.setAttribute("erro", "N� Guia deve ser informado");
                erro = true;
            }

            if(anoGuia==null || anoGuia.trim().equals("")){
                if(erro){
                    req.setAttribute("erro", "N� Guia deve ser informado.<br/>Ano Guia deve ser informado.");
                } else {
                    req.setAttribute("erro", "Ano Guia deve ser informado");
                }

            }
        }

        view.forward(req, resp);
    }

    private void atualizarDadosGuia(Guia guia, DataContext context) throws ServletException{
        try{
            Situacao situacao = (Situacao) DataObjectUtils.objectForPK(context, Situacao.class, Situacao.SITUACAO_CANCELADA);
            guia.setToSituacao(situacao);
            context.commitChanges();
        }catch(Exception e){
            context.rollbackChanges();
            throw new ServletException("<br/><br/>A Situa��o da Guia n�o foi alterada para CANCELADA.<br/>", e);
        }
    }

}
