package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._Beneficiario;
import java.util.List;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;

public class Beneficiario extends _Beneficiario {
    private Beneficiario titular = null;

    public String getMatServidor() {
        return (getObjectId() != null && !getObjectId().isTemporary())
                ? (String) getObjectId().getIdSnapshot().get(MAT_SERVIDOR_PK_COLUMN)
                : null;
    }

    public Beneficiario getToTitular() {
        if (titular == null) {
            DataContext context = this.getDataContext();
            Expression expBeneficiario = ExpressionFactory.matchDbExp(Beneficiario.MAT_SERVIDOR_PK_COLUMN, getMatServidor());
            expBeneficiario = expBeneficiario.andExp(ExpressionFactory.matchExp(Beneficiario.COD_DEPEND_PROPERTY, null));
            SelectQuery queryBeneficiario = new SelectQuery(Beneficiario.class, expBeneficiario);
            List<Beneficiario> listBeneficiario = context.performQuery(queryBeneficiario);
            if (listBeneficiario.size() != 1) {
                titular = this;
            } else {
                titular = listBeneficiario.get(0);
            }
        }
        return titular;
    }

    public String getMatNomeTipoDep() {
        String retorno = "";
        retorno += getToTitular().getMatServidor();
        if (getCodDepend() != null) {
            retorno += "/" + getCodDepend().toString();
        }
        retorno += " - ";
        retorno += getNome();
        if (getToTipoDependente() != null) {
            retorno += " (" + getToTipoDependente().getNomTipoDepend() + ")";
        }
        return retorno;
    }
}
