package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._TipoDependente;

public class TipoDependente extends _TipoDependente {

}
