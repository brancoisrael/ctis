package br.gov.tredf.tresaudeAdm.bean;

import br.gov.tredf.tresaudeAdm.bean.auto._Parametros;

public class Parametros extends _Parametros {

}
