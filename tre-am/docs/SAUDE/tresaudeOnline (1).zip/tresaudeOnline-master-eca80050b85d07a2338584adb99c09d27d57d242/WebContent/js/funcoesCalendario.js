

//FUNCAO QUE DIVIDE DATA
function VerificaData(campo, digData) {
    if (digData != "") {
        var bissexto = 0;
        var data = digData;
        var tam = data.length;
        if (tam == 10) {
            var dia = data.substr(0,2)
            var mes = data.substr(3,2)
            var ano = data.substr(6,4)
            if ((ano > 1900) && (ano < 2100)) {
                switch (mes) {
                    case '01':
                    case '03':
                    case '05':
                    case '07':
                    case '08':
                    case '10':
                    case '12':
                        if  (dia <= 31)  {
                            return true;
                        }
                        break
                  
                    case '04':        
                    case '06':
                    case '09':
                    case '11':
                        if  (dia <= 30) {
                            return true;
                        }
                        break
                    case '02':
                        /* Validando ano Bissexto / fevereiro / dia */
                        if ((ano % 4 == 0) || (ano % 100 == 0) || (ano % 400 == 0))  {
                            bissexto = 1;
                        }
                        if ((bissexto == 1) && (dia <= 29)) {
                            return true;                
                        }
                        if ((bissexto != 1) && (dia <= 28)) {
                            return true;
                        }            
                        break                        
                }
            }
            else {
                alert('Data Inv�lida.');
                campo.value = "";
                campo.focus();
                return false;          
            }
        }    
        alert('Data Inv�lida.');
        campo.value = "";
        campo.focus();
        return false;
    }
}

//-----> somente n�meros:

function v_NR(tecla) {
    if(typeof(tecla) == 'undefined')
    
    var tecla = window.event;
var codigo = (tecla.which ? tecla.which : tecla.keyCode ? tecla.keyCode : tecla.charCode);
    
    
// permite n�meros, 8=backspace, 46=del e 9=tab
    
if ( (codigo >= 48 && codigo <= 57) || (codigo >= 96 && codigo <= 105) || codigo == 8 || codigo == 46 || codigo == 9 ) {
    return true; }
else {
    return false; }
}
    
    
//-----> m�scara data:
    
function m_DATA(campo,tammax,tecla, txtdia, txtmes, txtano) {
    
if(typeof(tecla) == 'undefined')
    
var tecla = window.event;
var codigo = (tecla.which ? tecla.which : tecla.keyCode ? tecla.keyCode : tecla.charCode);
var vr = campo.value;
    
vr = vr.replace( "/", "" );
vr = vr.replace( "/", "" );
    
var tam = vr.length;
    
if (tam < tammax) { tam = vr.length + 1; }
if (codigo == 8) { tam = tam - 1; }
    
tam = tam - 1;
    
if ( (tam >= 2) && (tam < 3) ) {
vr = vr.substr( 0, tam - 0 ) + '/' + vr.substr( tam - 0, 2 ); }
    
if ( (tam >= 3) && (tam < 4) ) {
vr = vr.substr( 0, tam - 1 ) + '/' + vr.substr( tam - 1, 2 ); }
    
if (tam == 4) {
vr = vr.substr( 0, tam - 2 ) + '/' + vr.substr( tam - 2, 2 ) + '/' + vr.substr( tam - 0, 5 ); }
    
if (tam == 5) {
vr = vr.substr( 0, tam - 3 ) + '/' + vr.substr( tam - 3, 2 ) + '/' + vr.substr( tam - 1, 6 ); }
    
if (tam == 6) {
vr = vr.substr( 0, tam - 4 ) + '/' + vr.substr( tam - 4, 2 ) + '/' + vr.substr( tam - 2, 7 ); }
    
if (tam == 7) {
vr = vr.substr( 0, tam - 5 ) + '/' + vr.substr( tam - 5, 2 ) + '/' + vr.substr( tam - 3, 8 ); }
    
campo.value = vr;
}
