if (navigator.appName.indexOf('Microsoft') != -1){
    clientNavigator = "IE";
}else{
    clientNavigator = "Other";
}

function bloqueiaCaracteres(evnt) {
    //Fun��o permite digita��o de n�meros
    if (clientNavigator == "IE"){
        if (evnt.keyCode < 48 || evnt.keyCode > 57){
            event.returnValue = false;
        }
    }else{
        if ((evnt.charCode < 48 || evnt.charCode > 57) && evnt.keyCode == 0){
            event.returnValue = false;
        }
    }
}