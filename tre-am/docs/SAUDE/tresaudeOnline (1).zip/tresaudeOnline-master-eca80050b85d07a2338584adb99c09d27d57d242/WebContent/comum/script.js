// JavaScript Document
$(document).ready(function(){

// Menu versao 1.0.0

	$(".abrir").click(function(){	
		 if ( $(this).next().hasClass("submenu"))
			$(this).next().toggle("slide");
	});
	$(".nivel-1").click(function(){
		$(".submenu").addClass("fechar");
		$(".submenu").find('ul').removeClass("fechar");
		$(".fechar").hide();
		$(this).children('.submenu').show();
	});
	$("html").click(function(){
		 $(".submenu").hide();
	});	
	$('#menu').click(function(event){
		event.stopPropagation();
	});

//Colocar tamanho padrao nas labels e nas divs dos inputs radio e checkbox

	var tamanho_labels = new Array();
	var tamanho_div_check = new Array();
	var tamanho_div_radio = new Array();
	
	$("label").each(function(){
		tamanho_labels.push($(this).width());
	});
	
	$(".input-checkbox").each(function(){
		tamanho_div_check.push($(this).width());
	});
	
	$(".input-radio").each(function(){
		tamanho_div_radio.push($(this).width());
	});
	   
	var pega_maior = Math.max.apply(Math,tamanho_labels);
	var pega_tamanho_div_check = Math.max.apply(Math,tamanho_div_check);
	var pega_tamanho_div_radio = Math.max.apply(Math,tamanho_div_radio);


	
	$('head').append('<style type="text/css">label {width:'+(pega_maior+2)+'px !important;}.input-checkbox, .input-radio{padding-left:'+(pega_maior+10)+'px !important;}.input-checkbox{width: 100%;max-width:'+(pega_tamanho_div_check-pega_maior+2)+'px !important;}.input-radio{width: 100%;max-width:'+(pega_tamanho_div_radio-pega_maior+2)+'px !important;}</style>');

});


//tabela zebra

$(document).ready(function(){
	$("table.tabela tbody tr:even").css("background","#eaeaea");
	$("table.tabela tbody tr:odd").css("background","#fff");
});

// Menu em abas
$(document).ready(function() {
	$('.menu-aba li a').click(function() {
		if (!$(this).parent().hasClass('ativo')) {
			nomeAba = 'div.' + $(this).parent().attr('class');
			$(this).parent().addClass('ativo').siblings('li').removeClass('ativo');
			$(nomeAba).show().siblings().hide();
		}
	});
});

// Menu superior em abas
$(document).ready(function() {
	$('.menu-sup li a').click(function() {
		if (!$(this).parent().hasClass('ativo')) {
			nomeAba = 'div.' + $(this).parent().attr('class');
			$(this).parent().addClass('ativo').siblings('li').removeClass('ativo');
			$(nomeAba).show().siblings().hide();
		}
	});
});

//cÃ³digo de redimensionamento da altura do iframe de acordo com o tamanho do conteÃºdo interno

function getDocHeight(doc) {
    doc = doc || document;
    var body = doc.body, html = doc.documentElement;
    var height = Math.max( body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight );
    return height;
}

function setIframeHeight(id) {
    var ifrm = document.getElementById(id);
    var doc = ifrm.contentDocument? ifrm.contentDocument: ifrm.contentWindow.document;
    ifrm.style.visibility = 'hidden';
    ifrm.style.height = "10px"; // reset to minimal height in case going from longer to shorter doc
    ifrm.style.height = getDocHeight( doc ) + 5+"px";
    ifrm.style.visibility = 'visible';
}


// cÃ³digo para uso de mÃ¡scaras m formulÃ¡rios

// jQuery Mask Plugin v1.1.2
// github.com/igorescobar/jQuery-Mask-Plugin
(function(b){var u=function(a,g,f){var c=this;a=b(a);var l;g="function"==typeof g?g(a.val(),f):g;c.init=function(){f=f||{};c.byPassKeys=[8,9,37,38,39,40,46];c.translation={0:{pattern:/\d/},9:{pattern:/\d/,optional:!0},A:{pattern:/[a-zA-Z0-9]/},S:{pattern:/[a-zA-Z]/}};c.translation=b.extend({},c.translation,f.translation);c=b.extend(!0,{},c,f);a.each(function(){a.attr("maxlength",g.length).attr("autocomplete","off");d.destroyEvents();d.events();d.isInput()||d.val(d.getMasked())})};var d={events:function(){a.on("keydown.mask",
function(){l=d.val()});a.on("keyup.mask",d.behaviour);a.on("paste.mask",function(){setTimeout(function(){a.keydown().keyup()},100)})},destroyEvents:function(){a.off("keydown.mask").off("keyup.mask").off("paste.mask")},isInput:function(){return"input"===a.get(0).tagName.toLowerCase()},val:function(s){return 0<arguments.length?d.isInput()?a.val(s):a.text(s):d.isInput()?a.val():a.text()},behaviour:function(a){a=a||window.event;if(-1===b.inArray(a.keyCode||a.which,c.byPassKeys))return d.val(d.getMasked()),
d.callbacks(a)},getMasked:function(){var a=[],b=d.val(),e=0,t=g.length,h=0,l=b.length,k=1,m="push",n;f.reverse?(m="unshift",k=-1,e=t-1,h=l-1,n=function(){return-1<e&&-1<h}):n=function(){return e<t&&h<l};for(;n();){var p=g.charAt(e),q=c.translation[p],r=b.charAt(h);q?(r.match(q.pattern)?(a[m](r),e+=k):!0==q.optional&&(e+=k,h-=k),h+=k):(a[m](p),r==p&&(h+=k),e+=k)}return a.join("")},callbacks:function(b){var c=d.val(),e=d.val()!==l;if(!0===e&&"function"==typeof f.onChange)f.onChange(c,b,a,f);if(!0===
e&&"function"==typeof f.onKeyPress)f.onKeyPress(c,b,a,f);if("function"===typeof f.onComplete&&c.length===g.length)f.onComplete(c,b,a,f)}};c.remove=function(){d.destroyEvents();d.val(c.getCleanVal()).removeAttr("maxlength")};c.getCleanVal=function(){for(var a=[],b=d.val(),e=0,f=g.length;e<f;e++)c.translation[g.charAt(e)]&&a.push(b.charAt(e));return a.join("")};c.init()};b.fn.mask=function(a,g){return this.each(function(){b(this).data("mask",new u(this,a,g))})};b.fn.unmask=function(){return this.each(function(){b(this).data("mask").remove()})};
b("input[data-mask]").each(function(){b(this).mask(b(this).attr("data-mask"))})})(window.jQuery||window.Zepto);

